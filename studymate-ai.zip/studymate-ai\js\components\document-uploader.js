/**
 * StudyMate AI — Document Uploader Component
 * Handles file selection, drag-drop, upload, and processing pipeline display.
 */
window.DocumentUploaderComponent = {
  uploadQueue: [],
  isUploading: false,

  render(containerId, opts = {}) {
    const { subjectId = null, onComplete = null, compact = false } = opts;
    return `
      <div class="file-dropzone" id="dropzone-${containerId}">
        <input type="file" id="file-input-${containerId}" 
               accept=".pdf,.txt,.docx"
               multiple
               onchange="DocumentUploaderComponent.handleFileSelect(event, '${containerId}', '${subjectId}', ${onComplete ? `'${onComplete}'` : 'null'})" />
        <div class="file-dropzone-icon">📄</div>
        <div class="file-dropzone-title">${compact ? 'Upload Documents' : 'Drop your study materials here'}</div>
        <div class="file-dropzone-subtitle">
          PDF, TXT, DOCX supported · Max ${UsageService.getPlan().limits.max_file_size_mb}MB per file
        </div>
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('file-input-${containerId}').click()">
          ⬆️ Choose Files
        </button>
      </div>
      <div id="upload-progress-${containerId}"></div>
    `;
  },

  async handleFileSelect(event, containerId, subjectId, onCompleteCallback) {
    const files = Array.from(event.target.files);
    if (!files.length) return;

    // Usage check
    const limitCheck = UsageService.checkLimit('pdf_uploads_per_month');
    if (!limitCheck.allowed) {
      UpgradeModal.show('pdf_uploads_per_month', limitCheck);
      return;
    }

    const progressContainer = document.getElementById(`upload-progress-${containerId}`);
    const userId = AuthService.getCurrentUserId();

    for (const file of files) {
      await this.processFile(file, subjectId, userId, progressContainer, onCompleteCallback);
    }
    // Reset input
    event.target.value = '';
  },

  async processFile(file, subjectId, userId, progressContainer, onCompleteCallback) {
    const itemId = StorageService.generateId('ui_');

    // Validate file
    const plan = UsageService.getPlan();
    const validation = DocumentProcessor.validateFile(file, plan);
    if (!validation.valid) {
      Toast.error(validation.error);
      return;
    }

    // Create document record
    const doc = DB.Documents.create({
      name: file.name,
      subjectId: subjectId !== 'null' ? subjectId : null,
      fileType: file.type || file.name.split('.').pop(),
      fileSize: file.size,
      content: '',
    });

    // Render upload item
    if (progressContainer) {
      progressContainer.insertAdjacentHTML('afterbegin', this.renderUploadItem(itemId, file.name));
    }

    const updateStatus = (status, stageLabel, type = '') => {
      const statusEl = document.getElementById(`upload-status-${itemId}`);
      const progressEl = document.getElementById(`upload-prog-${itemId}`);
      if (statusEl) {
        statusEl.innerHTML = `${type === 'error' ? '❌' : type === 'done' ? '✅' : '<span class="spinner spinner-sm"></span>'} ${stageLabel}`;
      }
    };

    // Process
    await DocumentProcessor.processDocument(file, {
      documentId: doc.id,
      userId,
      subjectId,
      onProgress: ({ stage, label }) => {
        updateStatus(stage, label, stage === 'done' ? 'done' : stage === 'error' ? 'error' : '');
      },
    });

    // Update usage
    UsageService.incrementUsage('pdf_uploads_per_month');
    const sizeMB = file.size / (1024 * 1024);
    UsageService.incrementUsage('storage_mb', sizeMB);

    const updatedDoc = DB.Documents.get(doc.id);

    if (updatedDoc && updatedDoc.status === 'ready') {
      Toast.success(`"${file.name}" processed successfully`);
    } else {
      Toast.error(`Failed to process "${file.name}". ${updatedDoc?.processingError || ''}`);
    }

    if (onCompleteCallback && window[onCompleteCallback]) {
      window[onCompleteCallback](updatedDoc);
    }
  },

  renderUploadItem(id, name) {
    return `
      <div class="upload-item" id="upload-item-${id}">
        <span style="font-size:20px;">📄</span>
        <div class="upload-item-info">
          <div class="upload-item-name">${Helpers.truncate(name, 40)}</div>
          <div class="upload-item-status" id="upload-status-${id}">
            <span class="spinner spinner-sm"></span> Validating…
          </div>
          <div id="upload-prog-${id}"></div>
        </div>
      </div>
    `;
  },
};

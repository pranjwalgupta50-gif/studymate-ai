/**
 * StudyMate AI — Login Page
 */
window.LoginPage = {
  render() {
    const root = document.getElementById('app-root');
    if (!root) return;
    root.innerHTML = `
      <div class="auth-layout">
        <!-- Left Brand Panel -->
        <div class="auth-panel-left" style="background:linear-gradient(135deg,#4F46E5 0%,#7C3AED 60%,#06B6D4 100%);">
          <div style="text-align:center;color:white;max-width:380px;">
            <div style="font-size:72px;margin-bottom:24px;">📚</div>
            <h1 style="font-size:32px;font-weight:900;color:white;margin-bottom:16px;letter-spacing:-0.03em;">Welcome back!</h1>
            <p style="font-size:16px;opacity:0.85;line-height:1.7;">Your AI study partner is ready. Continue where you left off.</p>
            <div style="display:flex;flex-direction:column;gap:14px;margin-top:40px;text-align:left;">
              ${['RAG-powered answers from your documents','Smart quiz and notes generation','PYQ analysis and study planning'].map(f =>
                `<div style="display:flex;align-items:center;gap:10px;font-size:14px;opacity:0.9;"><span style="width:20px;text-align:center;">✓</span>${f}</div>`
              ).join('')}
            </div>
          </div>
        </div>

        <!-- Right Form Panel -->
        <div class="auth-panel-right">
          <div class="auth-form">
            <div class="auth-logo">
              <div class="auth-logo-icon">📚</div>
              <div class="auth-logo-name">StudyMate <strong>AI</strong></div>
            </div>

            <h2 class="auth-heading">Log in to your account</h2>
            <p class="auth-subheading">Don't have an account? <a href="#/register">Create one free</a></p>

            <div id="login-error" style="display:none;" class="alert alert-danger" style="margin-bottom:16px;">
              <span class="alert-icon">⚠</span>
              <span id="login-error-text"></span>
            </div>

            <form id="login-form" onsubmit="LoginPage.handleSubmit(event)" novalidate>
              <div style="display:flex;flex-direction:column;gap:18px;">
                <div class="form-group">
                  <label class="form-label" for="login-email">Email address <span class="required">*</span></label>
                  <div class="input-group">
                    <span class="input-icon-left">✉</span>
                    <input class="form-input" type="email" id="login-email" placeholder="your@email.com" required autocomplete="email" />
                  </div>
                </div>

                <div class="form-group">
                  <div style="display:flex;justify-content:space-between;align-items:center;">
                    <label class="form-label" for="login-password">Password <span class="required">*</span></label>
                    <a href="#/forgot-password" style="font-size:12px;">Forgot password?</a>
                  </div>
                  <div class="input-group">
                    <span class="input-icon-left">🔒</span>
                    <input class="form-input" type="password" id="login-password" placeholder="Enter your password" required autocomplete="current-password" />
                    <span class="input-icon-right" onclick="LoginPage.togglePassword('login-password', this)">👁</span>
                  </div>
                </div>

                <div class="form-check">
                  <input type="checkbox" id="remember-me" />
                  <label class="form-check-label" for="remember-me">Keep me logged in</label>
                </div>

                <button class="btn btn-primary btn-lg w-full" type="submit" id="login-submit" style="width:100%;margin-top:8px;">
                  Log In
                </button>

                <div class="divider-label">
                  <span>Or</span>
                </div>

                <button type="button" class="btn btn-outline btn-lg" onclick="LoginPage.handleDemo()" style="width:100%;">
                  🎯 Try with Demo Account
                </button>
              </div>
            </form>

            <p style="font-size:12px;color:var(--text-muted);text-align:center;margin-top:24px;">
              By logging in, you agree to StudyMate AI's terms of service.
            </p>
          </div>
        </div>
      </div>
    `;
  },

  togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    if (input.type === 'password') { input.type = 'text'; btn.textContent = '🙈'; }
    else { input.type = 'password'; btn.textContent = '👁'; }
  },

  async handleSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('login-email')?.value?.trim();
    const password = document.getElementById('login-password')?.value;
    const submitBtn = document.getElementById('login-submit');
    const errorEl = document.getElementById('login-error');
    const errorText = document.getElementById('login-error-text');

    if (!email || !password) {
      this.showError('Please fill in all fields');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.classList.add('btn-loading');
    submitBtn.textContent = 'Logging in…';
    if (errorEl) errorEl.style.display = 'none';

    try {
      const result = await AuthService.login({ email, password });
      if (result.success) {
        Toast.success(`Welcome back, ${result.user.name.split(' ')[0]}!`);
        Router.navigate('/dashboard');
      } else {
        this.showError(result.error || 'Login failed. Please try again.');
        submitBtn.disabled = false;
        submitBtn.classList.remove('btn-loading');
        submitBtn.textContent = 'Log In';
      }
    } catch (err) {
      this.showError('Login failed. Please try again.');
      submitBtn.disabled = false;
      submitBtn.classList.remove('btn-loading');
      submitBtn.textContent = 'Log In';
    }
  },

  showError(msg) {
    const errorEl = document.getElementById('login-error');
    const errorText = document.getElementById('login-error-text');
    if (errorEl && errorText) {
      errorText.textContent = msg;
      errorEl.style.display = 'flex';
    }
  },

  async handleDemo() {
    // Create or log in to a demo account
    const demoEmail = 'demo@studymateai.in';
    const demoPassword = 'Demo@2024';

    // Try login first
    const login = await AuthService.login({ email: demoEmail, password: demoPassword });
    if (login.success) {
      Toast.success('Welcome to the StudyMate AI demo!');
      Router.navigate('/dashboard');
      return;
    }

    // Create demo account
    const reg = await AuthService.register({
      name: 'Demo Student',
      email: demoEmail,
      password: demoPassword,
      course: 'B.Tech',
    });
    if (reg.success) {
      // Seed demo data
      this.seedDemoData(reg.user.id);
      Toast.success('Demo account created! Exploring StudyMate AI…');
      Router.navigate('/dashboard');
    } else {
      Toast.error('Could not create demo account. Please register instead.');
    }
  },

  seedDemoData(userId) {
    // Create a sample subject
    const sub = DB.Subjects.create({ name: 'Data Structures & Algorithms', code: 'CSE-201', semester: 'Semester 3', color: '#4F46E5' });
    DB.Subjects.create({ name: 'Database Management Systems', code: 'CSE-301', semester: 'Semester 5', color: '#06B6D4' });
    DB.Subjects.create({ name: 'Operating Systems', code: 'CSE-302', semester: 'Semester 5', color: '#10B981' });
  },
};

/**
 * StudyMate AI — Usage Tracking Service
 * Tracks per-user usage and enforces plan limits.
 * In production: all checks happen server-side before expensive operations.
 * Client checks are for UX only — never trust them for security.
 */

window.UsageService = (() => {
  function getUsageKey(userId) {
    const month = new Date().toISOString().slice(0, 7); // YYYY-MM
    return `usage_${userId}_${month}`;
  }

  function getUsage(userId = null) {
    const uid = userId || AuthService.getCurrentUserId();
    if (!uid) return {};
    const key = getUsageKey(uid);
    return StorageService.get(key, {
      pdf_uploads_per_month: 0,
      ai_questions_per_month: 0,
      notes_generations_per_month: 0,
      quiz_generations_per_month: 0,
      pyq_analyses_per_month: 0,
      storage_mb: 0,
    });
  }

  function incrementUsage(metric, amount = 1) {
    const uid = AuthService.getCurrentUserId();
    if (!uid) return;
    const key = getUsageKey(uid);
    const usage = getUsage(uid);
    usage[metric] = (usage[metric] || 0) + amount;
    StorageService.set(key, usage);
    // Log usage record
    StorageService.insertItem('usage_records', {
      id: StorageService.generateId('ur_'),
      userId: uid,
      metric,
      amount,
      recordedAt: new Date().toISOString(),
    });
  }

  function getPlan() {
    const plan = DB.Subscriptions.getCurrentPlan();
    return AppConfig.PLANS[plan] || AppConfig.PLANS.free;
  }

  function checkLimit(metric) {
    const plan = getPlan();
    const limit = plan.limits[metric];
    const usage = getUsage();
    const current = usage[metric] || 0;
    return {
      allowed: limit === undefined || current < limit,
      current,
      limit: limit || Infinity,
      remaining: limit !== undefined ? Math.max(0, limit - current) : Infinity,
      percentage: limit !== undefined ? Math.round((current / limit) * 100) : 0,
      metric,
    };
  }

  function checkAndConsume(metric, amount = 1) {
    const status = checkLimit(metric);
    if (!status.allowed) {
      return { allowed: false, ...status };
    }
    incrementUsage(metric, amount);
    return { allowed: true, ...status };
  }

  function getAllUsage() {
    const uid = AuthService.getCurrentUserId();
    if (!uid) return {};
    const plan = getPlan();
    const usage = getUsage(uid);
    const result = {};
    Object.keys(plan.limits).forEach(metric => {
      const current = usage[metric] || 0;
      const limit = plan.limits[metric];
      result[metric] = {
        current,
        limit,
        remaining: Math.max(0, limit - current),
        percentage: Math.round((current / limit) * 100),
      };
    });
    return result;
  }

  function hasFeature(featureName) {
    const plan = getPlan();
    return plan.features?.[featureName] ?? false;
  }

  return {
    getUsage,
    incrementUsage,
    checkLimit,
    checkAndConsume,
    getAllUsage,
    hasFeature,
    getPlan,
  };
})();

/**
 * StudyMate AI — Document Processor
 * Handles file validation, text extraction, chunking, and chunk storage.
 *
 * In production:
 * - PDF text extraction uses pdf.js or server-side python (PyMuPDF)
 * - DOCX extraction uses mammoth.js or server-side
 * - Chunking is semantic (sentence-aware)
 * - Embeddings are generated via AI provider embedding API
 * - Vector storage uses pgvector or Pinecone
 *
 * In this demo:
 * - PDF: Uses PDF.js CDN for real text extraction
 * - TXT: Direct FileReader
 * - Chunking: Sentence-aware character chunking
 * - Embeddings: Simulated (similarity search uses keyword matching)
 */

window.DocumentProcessor = (() => {
  const cfg = AppConfig;

  // ---- File Validation ----
  function validateFile(file, plan) {
    const maxMB = plan?.limits?.max_file_size_mb || 5;
    const maxBytes = maxMB * 1024 * 1024;

    if (!file) return { valid: false, error: 'No file provided' };

    const ext = '.' + file.name.split('.').pop().toLowerCase();
    if (!cfg.FILES.ALLOWED_EXTENSIONS.includes(ext)) {
      return {
        valid: false,
        error: `File type not supported. Allowed: ${cfg.FILES.ALLOWED_EXTENSIONS.join(', ')}`
      };
    }

    if (file.size > maxBytes) {
      return { valid: false, error: `File too large. Maximum size is ${maxMB}MB` };
    }

    if (file.size === 0) {
      return { valid: false, error: 'File is empty' };
    }

    return { valid: true };
  }

  // ---- Text extraction ----
  async function extractText(file) {
    const ext = '.' + file.name.split('.').pop().toLowerCase();

    if (ext === '.txt') {
      return await extractTxt(file);
    } else if (ext === '.pdf') {
      return await extractPdf(file);
    } else if (ext === '.docx') {
      return await extractDocx(file);
    }
    throw new Error('Unsupported file type');
  }

  async function extractTxt(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        const text = e.target.result;
        if (!text || text.trim().length < 10) {
          reject(new Error('File appears to be empty or contains no readable text'));
          return;
        }
        resolve({ text: text.trim(), pageCount: null, metadata: { encoding: 'utf-8' } });
      };
      reader.onerror = () => reject(new Error('Failed to read text file'));
      reader.readAsText(file);
    });
  }

  async function extractPdf(file) {
    // Use PDF.js if available, otherwise fallback
    if (typeof pdfjsLib !== 'undefined') {
      return await extractPdfWithPdfJs(file);
    }
    // Fallback: try to read as text (works only if PDF has embedded text stream)
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        const buffer = e.target.result;
        const bytes = new Uint8Array(buffer);
        // Check PDF magic number
        const header = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
        if (header !== '%PDF') {
          reject(new Error('Invalid or corrupted PDF file'));
          return;
        }
        // Simple text extraction from PDF byte stream (rough extraction)
        const text = extractTextFromPdfBytes(bytes);
        if (!text || text.trim().length < 20) {
          reject(new Error('This PDF appears to be image-only or has no extractable text. Please use a PDF with selectable text.'));
          return;
        }
        resolve({ text: text.trim(), pageCount: null, metadata: { method: 'byte-stream' } });
      };
      reader.onerror = () => reject(new Error('Failed to read PDF file'));
      reader.readAsArrayBuffer(file);
    });
  }

  async function extractPdfWithPdfJs(file) {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    const pageCount = pdf.numPages;

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(' ');
      fullText += `[Page ${i}]\n${pageText}\n\n`;
    }

    if (!fullText.trim() || fullText.trim().length < 20) {
      throw new Error('This PDF appears to be image-only or has no extractable text.');
    }
    return { text: fullText.trim(), pageCount, metadata: { method: 'pdfjs' } };
  }

  function extractTextFromPdfBytes(bytes) {
    // Rough extraction of visible text between parentheses in PDF stream
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(bytes);
    let text = '';
    let i = 0;
    while (i < raw.length) {
      if (raw[i] === '(' && (i === 0 || raw[i-1] !== '\\')) {
        let j = i + 1;
        let depth = 1;
        let str = '';
        while (j < raw.length && depth > 0) {
          if (raw[j] === '(' && raw[j-1] !== '\\') depth++;
          else if (raw[j] === ')' && raw[j-1] !== '\\') depth--;
          if (depth > 0) str += raw[j];
          j++;
        }
        // Filter: only add if mostly printable ASCII
        const printable = str.replace(/[^\x20-\x7E]/g, '');
        if (printable.length > 2) text += printable + ' ';
        i = j;
      } else {
        i++;
      }
    }
    return text.replace(/\s+/g, ' ').trim();
  }

  async function extractDocx(file) {
    // In production: use mammoth.js
    // For demo: read as plain text fallback
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        // DOCX is a ZIP file — extract text from word/document.xml
        const text = tryExtractDocxText(e.target.result);
        if (!text || text.trim().length < 10) {
          reject(new Error('Could not extract text from DOCX. Please convert to PDF or TXT.'));
          return;
        }
        resolve({ text: text.trim(), pageCount: null, metadata: { method: 'xml-extract' } });
      };
      reader.onerror = () => reject(new Error('Failed to read DOCX file'));
      reader.readAsArrayBuffer(file);
    });
  }

  function tryExtractDocxText(buffer) {
    try {
      const decoder = new TextDecoder('utf-8', { fatal: false });
      const raw = decoder.decode(buffer);
      // Extract text between <w:t> tags
      const matches = raw.match(/<w:t[^>]*>([^<]+)<\/w:t>/g) || [];
      return matches.map(m => m.replace(/<[^>]+>/g, '')).join(' ');
    } catch { return ''; }
  }

  // ---- Chunking ----
  function chunkText(text, docId, userId, metadata = {}) {
    const { CHUNK_SIZE, CHUNK_OVERLAP } = cfg.RAG;
    const chunks = [];
    let chunkIndex = 0;

    // Try to split on sentence boundaries
    const sentences = text.split(/(?<=[.!?])\s+/);
    let currentChunk = '';
    let currentPageRef = null;
    let sentenceIdx = 0;

    for (const sentence of sentences) {
      // Detect page marker
      const pageMatch = sentence.match(/^\[Page (\d+)\]/);
      if (pageMatch) { currentPageRef = parseInt(pageMatch[1]); }

      if (currentChunk.length + sentence.length > CHUNK_SIZE && currentChunk.length > 0) {
        chunks.push(createChunk(chunkIndex++, currentChunk.trim(), docId, userId, currentPageRef, metadata));
        // Overlap: keep last CHUNK_OVERLAP chars
        currentChunk = currentChunk.slice(-CHUNK_OVERLAP) + ' ' + sentence;
      } else {
        currentChunk += (currentChunk ? ' ' : '') + sentence;
      }
    }

    if (currentChunk.trim().length > 20) {
      chunks.push(createChunk(chunkIndex++, currentChunk.trim(), docId, userId, currentPageRef, metadata));
    }

    return chunks;
  }

  function createChunk(index, text, documentId, userId, pageNumber, metadata) {
    return {
      id: StorageService.generateId('chunk_'),
      documentId,
      userId,
      chunkIndex: index,
      text: text,
      pageNumber: pageNumber || null,
      // In production: this would be a real embedding vector
      // For demo: we store keyword fingerprint for similarity search
      keywords: extractKeywords(text),
      metadata,
      createdAt: new Date().toISOString(),
    };
  }

  // ---- Keyword extraction (replaces embeddings in demo) ----
  function extractKeywords(text) {
    const stopWords = new Set([
      'the','a','an','and','or','but','in','on','at','to','for','of','with',
      'by','is','are','was','were','be','been','being','have','has','had',
      'do','does','did','will','would','could','should','may','might','must',
      'this','that','these','those','it','its','i','you','he','she','we','they',
      'what','which','who','how','when','where','why','all','any','each',
    ]);
    const words = text.toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 3 && !stopWords.has(w));

    const freq = {};
    words.forEach(w => freq[w] = (freq[w] || 0) + 1);
    return Object.entries(freq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 30)
      .map(([word]) => word);
  }

  // ---- Main processing pipeline ----
  async function processDocument(file, { documentId, userId, subjectId, onProgress }) {
    const stages = [
      { key: 'validate',  label: 'Validating file…' },
      { key: 'extract',   label: 'Extracting text…' },
      { key: 'clean',     label: 'Cleaning text…' },
      { key: 'chunk',     label: 'Creating knowledge chunks…' },
      { key: 'index',     label: 'Indexing for search…' },
      { key: 'done',      label: 'Ready!' },
    ];

    const report = stage => onProgress && onProgress(stage);

    try {
      report({ stage: 'validate', label: stages[0].label });
      const plan = UsageService.getPlan();
      const validation = validateFile(file, plan);
      if (!validation.valid) throw new Error(validation.error);

      report({ stage: 'extract', label: stages[1].label });
      const { text, pageCount, metadata } = await extractText(file);

      report({ stage: 'clean', label: stages[2].label });
      const cleanedText = cleanText(text);

      report({ stage: 'chunk', label: stages[3].label });
      const chunks = chunkText(cleanedText, documentId, userId, metadata);

      report({ stage: 'index', label: stages[4].label });
      DB.Documents.saveChunks(chunks);

      // Update document record
      DB.Documents.update(documentId, {
        status: 'ready',
        content: cleanedText.slice(0, 5000), // store first 5k chars as preview
        chunkCount: chunks.length,
        pageCount: pageCount,
        metadata: { ...metadata, subjectId },
      });

      report({ stage: 'done', label: stages[5].label });
      return { success: true, chunkCount: chunks.length, pageCount };
    } catch (err) {
      DB.Documents.update(documentId, {
        status: 'failed',
        processingError: err.message,
      });
      report({ stage: 'error', label: err.message });
      return { success: false, error: err.message };
    }
  }

  function cleanText(text) {
    return text
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  return {
    validateFile,
    extractText,
    chunkText,
    processDocument,
    extractKeywords,
    cleanText,
  };
})();

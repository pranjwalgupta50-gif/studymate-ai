/**
 * StudyMate AI — Modal System
 */
window.Modal = (() => {
  function getRoot() { return document.getElementById('modal-root'); }

  function show(content, options = {}) {
    const root = getRoot();
    if (!root) return;
    const { size = '', id = 'active-modal' } = options;

    root.innerHTML = `
      <div class="modal-backdrop" id="${id}-backdrop">
        <div class="modal ${size ? 'modal-' + size : ''}" id="${id}" role="dialog" aria-modal="true">
          ${content}
        </div>
      </div>`;

    // Close on backdrop click
    document.getElementById(`${id}-backdrop`).addEventListener('click', e => {
      if (e.target === e.currentTarget) close();
    });

    // Close on Escape
    const escHandler = e => { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', escHandler); } };
    document.addEventListener('keydown', escHandler);
  }

  function close(id = 'active-modal') {
    const root = getRoot();
    if (root) root.innerHTML = '';
  }

  function confirm(message, onConfirm, options = {}) {
    const { title = 'Confirm', confirmText = 'Confirm', cancelText = 'Cancel', danger = false } = options;
    show(`
      <div class="modal-header">
        <h3 class="modal-title">${title}</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <p style="color:var(--text-secondary)">${message}</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Modal.close()">${cancelText}</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="confirm-btn">${confirmText}</button>
      </div>
    `, { size: 'sm' });

    document.getElementById('confirm-btn').addEventListener('click', () => {
      close();
      onConfirm();
    });
  }

  function alert(message, options = {}) {
    const { title = 'Notice', btnText = 'OK' } = options;
    show(`
      <div class="modal-header">
        <h3 class="modal-title">${title}</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <p style="color:var(--text-secondary)">${message}</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" onclick="Modal.close()">${btnText}</button>
      </div>
    `, { size: 'sm' });
  }

  return { show, close, confirm, alert };
})();

/**
 * StudyMate AI — Database Service
 * CRUD operations for all data models.
 * In production: all methods call a real backend API.
 *
 * Models: subjects, documents, conversations, messages,
 *         generated_notes, quizzes, quiz_attempts,
 *         pyq_analyses, study_plans, flashcard_decks, flashcards
 */

window.DB = (() => {
  const store = StorageService;
  const auth  = AuthService;

  function uid() { return auth.getCurrentUserId(); }
  function now() { return new Date().toISOString(); }

  // ============ SUBJECTS ============
  const Subjects = {
    create({ name, code, semester, color, description = '' }) {
      const userId = uid();
      if (!userId) throw new Error('Not authenticated');
      const subject = {
        id: store.generateId('sub_'),
        userId,
        name: name.trim(),
        code: (code || '').trim().toUpperCase(),
        semester: semester || '',
        color: color || AppConfig.ACADEMIC.DEFAULT_SUBJECT_COLORS[0],
        description,
        documentCount: 0,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('subjects', subject);
      return subject;
    },
    list() {
      const userId = uid();
      return store.queryItems('subjects', s => s.userId === userId)
        .sort((a, b) => a.name.localeCompare(b.name));
    },
    get(id) { return store.getItem('subjects', id); },
    update(id, updates) {
      store.updateItem('subjects', id, updates);
      return store.getItem('subjects', id);
    },
    delete(id) {
      // Cascade: delete documents in subject
      const docs = Documents.list(id);
      docs.forEach(d => Documents.delete(d.id));
      return store.deleteItem('subjects', id);
    },
  };

  // ============ DOCUMENTS ============
  const Documents = {
    create({ name, subjectId, fileType, fileSize, content, metadata = {} }) {
      const userId = uid();
      const doc = {
        id: store.generateId('doc_'),
        userId,
        subjectId: subjectId || null,
        name: name.trim(),
        fileType,
        fileSize,
        status: 'processing', // processing | ready | failed
        content: content || '', // extracted text
        chunkCount: 0,
        pageCount: metadata.pageCount || null,
        metadata,
        processingError: null,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('documents', doc);
      // Update subject doc count
      if (subjectId) {
        const sub = Subjects.get(subjectId);
        if (sub) Subjects.update(subjectId, { documentCount: (sub.documentCount || 0) + 1 });
      }
      return doc;
    },
    list(subjectId = null) {
      const userId = uid();
      return store.queryItems('documents', d =>
        d.userId === userId && (subjectId ? d.subjectId === subjectId : true)
      ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    get(id) { return store.getItem('documents', id); },
    update(id, updates) {
      store.updateItem('documents', id, updates);
      return store.getItem('documents', id);
    },
    delete(id) {
      const doc = store.getItem('documents', id);
      if (doc && doc.subjectId) {
        const sub = Subjects.get(doc.subjectId);
        if (sub) Subjects.update(doc.subjectId, { documentCount: Math.max(0, (sub.documentCount || 1) - 1) });
      }
      // Delete chunks
      const chunks = store.queryItems('document_chunks', c => c.documentId === id);
      chunks.forEach(c => store.deleteItem('document_chunks', c.id));
      return store.deleteItem('documents', id);
    },
    getChunks(documentId) {
      return store.queryItems('document_chunks', c => c.documentId === documentId);
    },
    saveChunks(chunks) {
      chunks.forEach(chunk => store.insertItem('document_chunks', chunk));
    },
  };

  // ============ CONVERSATIONS ============
  const Conversations = {
    create({ title = 'New Chat', subjectId = null, documentIds = [], mode = 'detailed' }) {
      const userId = uid();
      const conv = {
        id: store.generateId('conv_'),
        userId,
        title,
        subjectId,
        documentIds: documentIds || [],
        mode,
        messageCount: 0,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('conversations', conv);
      return conv;
    },
    list() {
      const userId = uid();
      return store.queryItems('conversations', c => c.userId === userId)
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    },
    get(id) { return store.getItem('conversations', id); },
    update(id, updates) {
      store.updateItem('conversations', id, updates);
      return store.getItem('conversations', id);
    },
    delete(id) {
      const msgs = store.queryItems('messages', m => m.conversationId === id);
      msgs.forEach(m => store.deleteItem('messages', m.id));
      return store.deleteItem('conversations', id);
    },
    getMessages(conversationId) {
      return store.queryItems('messages', m => m.conversationId === conversationId)
        .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    },
    addMessage({ conversationId, role, content, sources = [], mode = null }) {
      const msg = {
        id: store.generateId('msg_'),
        conversationId,
        role, // 'user' | 'assistant'
        content,
        sources, // [{documentId, documentName, chunkIndex, excerpt}]
        mode,
        createdAt: now(),
      };
      store.insertItem('messages', msg);
      // Update conversation
      const conv = Conversations.get(conversationId);
      if (conv) {
        Conversations.update(conversationId, {
          messageCount: (conv.messageCount || 0) + 1,
          title: conv.messageCount === 0 && role === 'user'
            ? content.slice(0, 60) + (content.length > 60 ? '…' : '')
            : conv.title,
          updatedAt: now(),
        });
      }
      return msg;
    },
  };

  // ============ NOTES ============
  const Notes = {
    create({ title, content, subjectId, documentIds = [], noteType = 'detailed', format = 'html' }) {
      const userId = uid();
      const note = {
        id: store.generateId('note_'),
        userId,
        title,
        content,
        subjectId,
        documentIds,
        noteType, // quick | detailed | exam | revision
        format,
        wordCount: content.split(/\s+/).length,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('generated_notes', note);
      return note;
    },
    list(subjectId = null) {
      const userId = uid();
      return store.queryItems('generated_notes', n =>
        n.userId === userId && (subjectId ? n.subjectId === subjectId : true)
      ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    get(id) { return store.getItem('generated_notes', id); },
    update(id, updates) { return store.updateItem('generated_notes', id, updates); },
    delete(id) { return store.deleteItem('generated_notes', id); },
  };

  // ============ QUIZZES ============
  const Quizzes = {
    create({ title, subjectId, documentIds = [], questions = [], settings = {} }) {
      const userId = uid();
      const quiz = {
        id: store.generateId('quiz_'),
        userId,
        title,
        subjectId,
        documentIds,
        questions,
        settings, // {count, difficulty, type, topic, timeLimit}
        attemptCount: 0,
        bestScore: null,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('quizzes', quiz);
      return quiz;
    },
    list(subjectId = null) {
      const userId = uid();
      return store.queryItems('quizzes', q =>
        q.userId === userId && (subjectId ? q.subjectId === subjectId : true)
      ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    get(id) { return store.getItem('quizzes', id); },
    update(id, updates) { return store.updateItem('quizzes', id, updates); },
    delete(id) { return store.deleteItem('quizzes', id); },

    saveAttempt({ quizId, answers, score, timeTaken, incorrectQuestions }) {
      const userId = uid();
      const attempt = {
        id: store.generateId('attempt_'),
        userId,
        quizId,
        answers,
        score,
        timeTaken,
        incorrectQuestions,
        completedAt: now(),
      };
      store.insertItem('quiz_attempts', attempt);
      // Update quiz best score
      const quiz = Quizzes.get(quizId);
      if (quiz) {
        Quizzes.update(quizId, {
          attemptCount: (quiz.attemptCount || 0) + 1,
          bestScore: Math.max(quiz.bestScore || 0, score),
        });
      }
      return attempt;
    },
    getAttempts(quizId) {
      const userId = uid();
      return store.queryItems('quiz_attempts', a => a.userId === userId && a.quizId === quizId)
        .sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt));
    },
    getAllAttempts() {
      const userId = uid();
      return store.queryItems('quiz_attempts', a => a.userId === userId)
        .sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt));
    },
  };

  // ============ PYQ ANALYSES ============
  const PYQAnalyses = {
    create({ title, subjectId, papers, analysis }) {
      const userId = uid();
      const pyq = {
        id: store.generateId('pyq_'),
        userId,
        title,
        subjectId,
        papers, // [{name, year, examType, documentId}]
        analysis, // {topics, patterns, questionBank}
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('pyq_analyses', pyq);
      return pyq;
    },
    list() {
      const userId = uid();
      return store.queryItems('pyq_analyses', p => p.userId === userId)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    get(id) { return store.getItem('pyq_analyses', id); },
    delete(id) { return store.deleteItem('pyq_analyses', id); },
  };

  // ============ STUDY PLANS ============
  const StudyPlans = {
    create({ title, subjectIds, examDate, hoursPerDay, tasks = [] }) {
      const userId = uid();
      const plan = {
        id: store.generateId('plan_'),
        userId,
        title,
        subjectIds,
        examDate,
        hoursPerDay,
        tasks, // [{id, date, title, subject, type, duration, completed}]
        completedTasks: 0,
        totalTasks: tasks.length,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('study_plans', plan);
      return plan;
    },
    list() {
      const userId = uid();
      return store.queryItems('study_plans', p => p.userId === userId)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    get(id) { return store.getItem('study_plans', id); },
    update(id, updates) { return store.updateItem('study_plans', id, updates); },
    delete(id) { return store.deleteItem('study_plans', id); },
    updateTask(planId, taskId, updates) {
      const plan = StudyPlans.get(planId);
      if (!plan) return false;
      const taskIdx = plan.tasks.findIndex(t => t.id === taskId);
      if (taskIdx === -1) return false;
      plan.tasks[taskIdx] = { ...plan.tasks[taskIdx], ...updates };
      plan.completedTasks = plan.tasks.filter(t => t.completed).length;
      return store.updateItem('study_plans', planId, { tasks: plan.tasks, completedTasks: plan.completedTasks });
    },
  };

  // ============ FLASHCARD DECKS ============
  const Flashcards = {
    createDeck({ title, subjectId, cards = [] }) {
      const userId = uid();
      const deck = {
        id: store.generateId('deck_'),
        userId,
        title,
        subjectId,
        cards, // [{id, front, back, difficulty, learned, lastReviewed}]
        cardCount: cards.length,
        learnedCount: 0,
        createdAt: now(),
        updatedAt: now(),
      };
      store.insertItem('flashcard_decks', deck);
      return deck;
    },
    listDecks(subjectId = null) {
      const userId = uid();
      return store.queryItems('flashcard_decks', d =>
        d.userId === userId && (subjectId ? d.subjectId === subjectId : true)
      ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },
    getDeck(id) { return store.getItem('flashcard_decks', id); },
    updateDeck(id, updates) { return store.updateItem('flashcard_decks', id, updates); },
    deleteDeck(id) { return store.deleteItem('flashcard_decks', id); },
    updateCard(deckId, cardId, updates) {
      const deck = Flashcards.getDeck(deckId);
      if (!deck) return false;
      const cardIdx = deck.cards.findIndex(c => c.id === cardId);
      if (cardIdx === -1) return false;
      deck.cards[cardIdx] = { ...deck.cards[cardIdx], ...updates, lastReviewed: now() };
      deck.learnedCount = deck.cards.filter(c => c.learned).length;
      return store.updateItem('flashcard_decks', deckId, { cards: deck.cards, learnedCount: deck.learnedCount });
    },
  };

  // ============ PROGRESS TRACKING ============
  const Progress = {
    getStats() {
      const userId = uid();
      const docs     = store.queryItems('documents', d => d.userId === userId && d.status === 'ready');
      const subjects = store.queryItems('subjects', s => s.userId === userId);
      const notes    = store.queryItems('generated_notes', n => n.userId === userId);
      const quizzes  = store.queryItems('quiz_attempts', a => a.userId === userId);
      const plans    = store.queryItems('study_plans', p => p.userId === userId);
      const convs    = store.queryItems('conversations', c => c.userId === userId);
      const decks    = store.queryItems('flashcard_decks', d => d.userId === userId);

      const totalQuestions  = quizzes.reduce((s, a) => {
        const quiz = store.getItem('quizzes', a.quizId);
        return s + (quiz ? quiz.questions.length : 0);
      }, 0);
      const correctAnswers  = quizzes.reduce((s, a) => s + Math.round((a.score / 100) * (store.getItem('quizzes', a.quizId)?.questions?.length || 0)), 0);
      const avgScore = quizzes.length > 0
        ? Math.round(quizzes.reduce((s, a) => s + a.score, 0) / quizzes.length)
        : 0;

      const completedTasks  = plans.reduce((s, p) => s + (p.completedTasks || 0), 0);
      const totalTasks      = plans.reduce((s, p) => s + (p.totalTasks || 0), 0);

      return {
        totalDocuments:   docs.length,
        totalSubjects:    subjects.length,
        totalNotes:       notes.length,
        totalQuizAttempts: quizzes.length,
        averageQuizScore: avgScore,
        correctAnswers,
        totalQuestions,
        totalChatSessions: convs.length,
        completedPlanTasks: completedTasks,
        totalPlanTasks: totalTasks,
        flashcardDecks: decks.length,
        flashcardsLearned: decks.reduce((s, d) => s + (d.learnedCount || 0), 0),
        totalFlashcards: decks.reduce((s, d) => s + (d.cardCount || 0), 0),
      };
    },
    getWeakTopics() {
      const userId = uid();
      const attempts = store.queryItems('quiz_attempts', a => a.userId === userId);
      const weakTopics = {};
      attempts.forEach(a => {
        (a.incorrectQuestions || []).forEach(q => {
          const topic = q.topic || 'General';
          weakTopics[topic] = (weakTopics[topic] || 0) + 1;
        });
      });
      return Object.entries(weakTopics)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([topic, count]) => ({ topic, count }));
    },
  };

  // ============ SUBSCRIPTIONS ============
  const Subscriptions = {
    get(userId = null) {
      const id = userId || uid();
      return store.queryItems('subscriptions', s => s.userId === id)[0] || null;
    },
    getCurrentPlan() {
      const sub = Subscriptions.get();
      return sub ? sub.plan : 'free';
    },
    upgrade(plan) {
      const userId = uid();
      const sub = Subscriptions.get(userId);
      if (sub) {
        store.updateItem('subscriptions', sub.id, { plan, status: 'active' });
      }
    },
  };

  return {
    Subjects, Documents, Conversations,
    Notes, Quizzes, PYQAnalyses,
    StudyPlans, Flashcards,
    Progress, Subscriptions,
  };
})();

/**
 * StudyMate AI — PYQ Analyzer Page
 */
window.PYQAnalyzerPage = {
  currentAnalysis: null,

  render() {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const saved = DB.PYQAnalyses.list();
    const docs = DB.Documents.list().filter(d => d.status === 'ready');

    root.innerHTML = AppShell.renderLayout('PYQ Analyzer', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">🔍 PYQ Analyzer</h1>
          <p class="page-subtitle">Analyze previous year question papers to identify important topics and patterns</p>
        </div>
      </div>

      <div class="alert alert-neutral" style="margin-bottom:24px;">
        <span class="alert-icon">ℹ</span>
        <span>PYQ analysis shows what has appeared in past papers based on your uploaded documents. It does <strong>not</strong> guarantee that any topic will appear in your exam.</span>
      </div>

      <div class="grid" style="grid-template-columns:340px 1fr;gap:24px;">
        <!-- Config Panel -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <div class="card-header"><div class="card-title">Analyze PYQs</div></div>
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div class="form-group">
                <label class="form-label">Analysis Title <span class="required">*</span></label>
                <input class="form-input" id="pyq-title" type="text" placeholder="e.g. DBMS End-Sem PYQ Analysis" />
              </div>
              <div class="form-group">
                <label class="form-label">Subject</label>
                <select class="form-select" id="pyq-subject">
                  <option value="">Select subject</option>
                  ${subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Course</label>
                <select class="form-select" id="pyq-course">
                  ${AppConfig.ACADEMIC.COURSE_TYPES.map(c => `<option value="${c}">${c}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Select PYQ Documents <span class="required">*</span></label>
                <div style="max-height:200px;overflow-y:auto;border:1px solid var(--border-default);border-radius:var(--radius-md);padding:8px;">
                  ${docs.length === 0
                    ? `<div style="font-size:13px;color:var(--text-muted);padding:8px;text-align:center;">No documents uploaded yet.<br/><a href="#/documents" class="btn btn-sm btn-primary" style="margin-top:8px;">Upload PYQs</a></div>`
                    : docs.map(d => `
                        <div class="form-check" style="padding:6px 4px;">
                          <input type="checkbox" id="pyq-doc-${d.id}" value="${d.id}" class="pyq-doc-check" />
                          <label class="form-check-label" for="pyq-doc-${d.id}" style="font-size:12px;">${Helpers.truncate(d.name, 38)}</label>
                        </div>
                      `).join('')
                  }
                </div>
              </div>
              <button class="btn btn-primary" onclick="PYQAnalyzerPage.analyze()">
                🔍 Analyze PYQs
              </button>
            </div>
          </div>

          <!-- Saved Analyses -->
          ${saved.length > 0 ? `
            <div class="card">
              <div class="card-header"><div class="card-title">Past Analyses</div></div>
              <div style="display:flex;flex-direction:column;gap:8px;max-height:250px;overflow-y:auto;">
                ${saved.map(a => `
                  <div style="padding:10px;border:1px solid var(--border-default);border-radius:10px;cursor:pointer;transition:var(--transition-fast);"
                       onclick="PYQAnalyzerPage.loadAnalysis('${a.id}')"
                       onmouseenter="this.style.borderColor='var(--brand-primary)'"
                       onmouseleave="this.style.borderColor='var(--border-default)'">
                    <div style="font-size:13px;font-weight:600;">${Helpers.truncate(a.title,32)}</div>
                    <div style="font-size:11px;color:var(--text-muted);">${a.papers?.length || 0} papers · ${Helpers.formatDate(a.createdAt)}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Analysis Output -->
        <div id="pyq-output">
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;text-align:center;color:var(--text-muted);">
            <div style="font-size:64px;opacity:0.3;">🔍</div>
            <div style="font-size:16px;font-weight:600;">PYQ analysis will appear here</div>
            <div style="font-size:13px;max-width:400px;">Upload previous year question papers as PDFs or TXT files, then select them above and click Analyze.</div>
          </div>
        </div>
      </div>
    `);
  },

  async analyze() {
    const title = document.getElementById('pyq-title')?.value?.trim();
    if (!title) { Toast.error('Please enter an analysis title'); return; }

    const selectedDocs = Array.from(document.querySelectorAll('.pyq-doc-check:checked')).map(c => c.value);
    if (selectedDocs.length === 0) { Toast.error('Please select at least one PYQ document'); return; }

    const limitResult = UsageService.checkLimit('pyq_analyses_per_month');
    if (!limitResult.allowed) { UpgradeModal.show('pyq_analyses_per_month', limitResult); return; }
    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const subjectId = document.getElementById('pyq-subject')?.value;
    const course = document.getElementById('pyq-course')?.value || 'B.Tech';

    // Collect content from all selected documents
    const docsData = selectedDocs.map(id => DB.Documents.get(id)).filter(Boolean);
    const papersContent = docsData.map(d => `=== ${d.name} ===\n${d.content || ''}`).join('\n\n');

    const subject = subjectId ? DB.Subjects.get(subjectId) : null;

    // Show loading
    const output = document.getElementById('pyq-output');
    if (output) {
      output.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
          <div class="spinner spinner-xl"></div>
          <div>
            <div style="font-size:15px;font-weight:600;">Analyzing ${docsData.length} question paper${docsData.length !== 1 ? 's' : ''}…</div>
            <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">Identifying patterns, topics, and question frequency</div>
          </div>
        </div>
      `;
    }

    try {
      const analysis = await AIService.analyzePYQs({
        papersContent,
        subject: subject?.name || 'General',
        course,
      });

      UsageService.incrementUsage('pyq_analyses_per_month');

      const savedAnalysis = DB.PYQAnalyses.create({
        title,
        subjectId,
        papers: docsData.map(d => ({ name: d.name, documentId: d.id })),
        analysis,
      });

      this.currentAnalysis = savedAnalysis;
      this.renderAnalysis(savedAnalysis);
      Toast.success('PYQ analysis complete!');
    } catch (err) {
      if (output) {
        output.innerHTML = `
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
            <div style="font-size:48px;">⚠️</div>
            <div style="font-size:15px;font-weight:600;color:var(--brand-danger);">Analysis Failed</div>
            <div style="font-size:13px;color:var(--text-muted);text-align:center;">${err.message}</div>
            <button class="btn btn-outline" onclick="PYQAnalyzerPage.analyze()">↻ Try Again</button>
          </div>
        `;
      }
      Toast.error('PYQ analysis failed: ' + err.message);
    }
  },

  loadAnalysis(id) {
    const a = DB.PYQAnalyses.get(id);
    if (a) this.renderAnalysis(a);
  },

  renderAnalysis(analysis) {
    const output = document.getElementById('pyq-output');
    if (!output) return;
    const data = analysis.analysis;
    const topics = data?.topics || [];
    const patterns = data?.patterns || {};
    const questionBank = data?.questionBank || [];

    const freqColors = {
      frequently_asked: 'pyq-freq-high',
      repeated_recently: 'pyq-freq-recent',
      appeared_occasionally: 'pyq-freq-medium',
      less_frequently_seen: 'pyq-freq-low',
    };
    const freqLabels = {
      frequently_asked: '🔥 Frequently Asked',
      repeated_recently: '✨ Repeated Recently',
      appeared_occasionally: '📌 Appeared Occasionally',
      less_frequently_seen: '📎 Less Frequent',
    };

    output.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:20px;">
        <!-- Summary -->
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">📊 ${analysis.title}</div>
              <div class="card-subtitle">${analysis.papers?.length || 0} papers analyzed · ${Helpers.formatDate(analysis.createdAt)}</div>
            </div>
            <div style="display:flex;gap:8px;">
              <div class="stat-card" style="padding:12px 20px;flex-direction:row;align-items:center;gap:12px;">
                <span style="font-size:22px;font-weight:800;">${patterns.totalQuestions || topics.length}</span>
                <span style="font-size:12px;color:var(--text-muted);">Questions Found</span>
              </div>
              <div class="stat-card" style="padding:12px 20px;flex-direction:row;align-items:center;gap:12px;">
                <span style="font-size:22px;font-weight:800;">${patterns.uniqueTopics || topics.length}</span>
                <span style="font-size:12px;color:var(--text-muted);">Unique Topics</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Tabs -->
        <div>
          <div class="tabs tabs-underline" id="pyq-tabs">
            <button class="tab-btn active" onclick="PYQAnalyzerPage.switchTab('topics')">📋 Topic Analysis</button>
            <button class="tab-btn" onclick="PYQAnalyzerPage.switchTab('bank')">📚 Question Bank (${questionBank.length})</button>
          </div>

          <!-- Topics Tab -->
          <div id="tab-topics" style="margin-top:20px;">
            <div style="display:flex;flex-direction:column;gap:12px;">
              ${topics.length === 0
                ? `<div class="empty-state"><div class="empty-state-icon">📊</div><div class="empty-state-title">No topics identified</div><div class="empty-state-desc">The AI could not identify specific topics. Try with clearer PYQ documents.</div></div>`
                : topics.sort((a, b) => b.frequency - a.frequency).map(topic => `
                    <div class="pyq-topic-bar">
                      <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div class="pyq-topic-name">${topic.name}</div>
                        <span class="pyq-freq-label ${freqColors[topic.classification] || 'pyq-freq-low'}">${freqLabels[topic.classification] || topic.classification}</span>
                      </div>
                      <div style="display:flex;gap:12px;align-items:center;">
                        <div class="progress-bar" style="flex:1;">
                          <div class="progress-fill" style="width:${Math.min(100, (topic.frequency / (topics[0]?.frequency || 1)) * 100)}%;"></div>
                        </div>
                        <span style="font-size:13px;font-weight:700;color:var(--brand-primary);">${topic.frequency}x</span>
                      </div>
                      ${topic.years && topic.years.length > 0 ? `
                        <div style="display:flex;gap:6px;flex-wrap:wrap;">
                          <span style="font-size:12px;color:var(--text-muted);">Appeared in:</span>
                          ${topic.years.map(y => `<span class="tag" style="font-size:11px;">${y}</span>`).join('')}
                        </div>
                      ` : ''}
                      ${topic.questions && topic.questions.length > 0 ? `
                        <details style="margin-top:4px;">
                          <summary style="font-size:12px;color:var(--brand-primary);cursor:pointer;">View sample questions (${topic.questions.length})</summary>
                          <ul style="margin-top:8px;padding-left:16px;">
                            ${topic.questions.slice(0,3).map(q => `<li style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;">${q}</li>`).join('')}
                          </ul>
                        </details>
                      ` : ''}
                    </div>
                  `).join('')
              }
            </div>
          </div>

          <!-- Question Bank Tab -->
          <div id="tab-bank" style="margin-top:20px;display:none;">
            <div style="margin-bottom:12px;">
              <input type="text" class="form-input" placeholder="Search questions…" oninput="PYQAnalyzerPage.filterQuestions(this.value)" />
            </div>
            <div style="display:flex;flex-direction:column;gap:10px;" id="question-bank-list">
              ${questionBank.length === 0
                ? `<div class="empty-state"><div class="empty-state-title">No questions extracted</div></div>`
                : questionBank.map((q, i) => `
                    <div class="card card-sm">
                      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
                        <div style="flex:1;">
                          <div style="font-size:14px;color:var(--text-primary);margin-bottom:6px;">${q.question}</div>
                          <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            ${q.year ? `<span class="badge badge-primary" style="font-size:10px;">${q.year}</span>` : ''}
                            ${q.unit ? `<span class="badge badge-gray" style="font-size:10px;">${q.unit}</span>` : ''}
                            ${q.topic ? `<span class="badge badge-cyan" style="font-size:10px;">${q.topic}</span>` : ''}
                            ${q.marks ? `<span class="badge badge-warning" style="font-size:10px;">${q.marks} marks</span>` : ''}
                          </div>
                        </div>
                        <div style="display:flex;gap:6px;flex-shrink:0;">
                          <button class="btn btn-sm btn-outline" onclick="AIChatPage.fillInput('Explain: ${q.question.replace(/'/g,'')}');Router.navigate('/ai-chat');">Ask AI</button>
                        </div>
                      </div>
                    </div>
                  `).join('')
              }
            </div>
          </div>
        </div>

        <div class="ai-disclaimer">
          <span class="ai-disclaimer-icon">⚠</span>
          This analysis is based only on your uploaded documents. Topics shown do not guarantee exam appearance. Always study all topics.
        </div>
      </div>
    `;
  },

  switchTab(tab) {
    document.querySelectorAll('#pyq-tabs .tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('tab-topics').style.display = tab === 'topics' ? 'block' : 'none';
    document.getElementById('tab-bank').style.display   = tab === 'bank'   ? 'block' : 'none';
  },

  filterQuestions: Helpers.debounce(function(query) {
    const items = document.querySelectorAll('#question-bank-list .card');
    items.forEach(item => {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(query.toLowerCase()) ? 'block' : 'none';
    });
  }, 300),
};

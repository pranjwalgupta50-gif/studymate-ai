/**
 * StudyMate AI — Quiz Generator & Player Page
 */
window.QuizPage = {
  currentQuiz: null,
  currentQ: 0,
  answers: {},
  submitted: false,
  timerInterval: null,
  timeLeft: 0,

  render(params = {}) {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    const savedQuizzes = DB.Quizzes.list();

    root.innerHTML = AppShell.renderLayout('Quiz Generator', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">✏️ Quiz Generator</h1>
          <p class="page-subtitle">Generate AI-powered quizzes from your study material</p>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:320px 1fr;gap:24px;">
        <!-- Config Panel -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <div class="card-header"><div class="card-title">Create Quiz</div></div>
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div class="form-group">
                <label class="form-label">Topic / Subject <span class="required">*</span></label>
                <input class="form-input" id="quiz-topic" type="text" placeholder="e.g. Binary Search Trees" />
              </div>
              <div class="form-group">
                <label class="form-label">Source Document</label>
                <select class="form-select" id="quiz-doc">
                  <option value="">All documents</option>
                  ${docs.map(d => `<option value="${d.id}">${Helpers.truncate(d.name,38)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Question Type</label>
                <select class="form-select" id="quiz-type">
                  <option value="mcq">MCQ (Multiple Choice)</option>
                  <option value="truefalse">True / False</option>
                  <option value="short">Short Answer</option>
                  <option value="fillblanks">Fill in the Blanks</option>
                </select>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <div class="form-group">
                  <label class="form-label">Questions</label>
                  <select class="form-select" id="quiz-count">
                    <option value="5">5 questions</option>
                    <option value="10" selected>10 questions</option>
                    <option value="15">15 questions</option>
                    <option value="20">20 questions</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Difficulty</label>
                  <select class="form-select" id="quiz-difficulty">
                    <option value="easy">Easy</option>
                    <option value="medium" selected>Medium</option>
                    <option value="hard">Hard</option>
                  </select>
                </div>
              </div>
              <button class="btn btn-primary" onclick="QuizPage.generateQuiz()">
                🤖 Generate Quiz
              </button>
            </div>
          </div>

          <!-- Saved Quizzes -->
          <div class="card">
            <div class="card-header"><div class="card-title">Saved Quizzes (${savedQuizzes.length})</div></div>
            ${savedQuizzes.length === 0
              ? '<div style="font-size:13px;color:var(--text-muted);padding:12px;text-align:center;">No quizzes yet</div>'
              : `<div style="display:flex;flex-direction:column;gap:8px;max-height:300px;overflow-y:auto;">
                  ${savedQuizzes.map(q => `
                    <div style="padding:10px;border:1px solid var(--border-default);border-radius:10px;cursor:pointer;transition:var(--transition-fast);"
                         onclick="QuizPage.startSavedQuiz('${q.id}')"
                         onmouseenter="this.style.borderColor='var(--brand-primary)'"
                         onmouseleave="this.style.borderColor='var(--border-default)'">
                      <div style="font-size:13px;font-weight:600;">${Helpers.truncate(q.title,30)}</div>
                      <div style="font-size:11px;color:var(--text-muted);">
                        ${q.questions.length} questions · Best: ${q.bestScore !== null ? q.bestScore + '%' : 'Not attempted'}
                      </div>
                    </div>
                  `).join('')}
                </div>`
            }
          </div>
        </div>

        <!-- Quiz Area -->
        <div id="quiz-area">
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;gap:16px;color:var(--text-muted);background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
            <div style="font-size:64px;opacity:0.3;">✏️</div>
            <div style="font-size:16px;font-weight:600;">Your quiz will appear here</div>
            <div style="font-size:13px;text-align:center;max-width:300px;">Configure the options on the left and generate a quiz from your study material.</div>
          </div>
        </div>
      </div>
    `);
  },

  async generateQuiz() {
    const topic = document.getElementById('quiz-topic')?.value?.trim();
    if (!topic) { Toast.error('Please enter a topic'); return; }

    const limitResult = UsageService.checkLimit('quiz_generations_per_month');
    if (!limitResult.allowed) { UpgradeModal.show('quiz_generations_per_month', limitResult); return; }
    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const docId = document.getElementById('quiz-doc')?.value;
    const type = document.getElementById('quiz-type')?.value || 'mcq';
    const count = parseInt(document.getElementById('quiz-count')?.value || '10');
    const difficulty = document.getElementById('quiz-difficulty')?.value || 'medium';

    // Get content
    const chunks = RAGEngine.retrieve({ query: topic, documentIds: docId ? [docId] : null, topK: 8 });
    const content = chunks.length > 0
      ? chunks.map(c => c.text).join('\n\n')
      : (docId ? (DB.Documents.get(docId)?.content || '') : topic);

    // Show loading
    const quizArea = document.getElementById('quiz-area');
    if (quizArea) {
      quizArea.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
          <div class="spinner spinner-xl"></div>
          <div style="font-size:15px;font-weight:600;">Generating ${count} questions…</div>
          <div style="font-size:13px;color:var(--text-muted);">This may take 20-40 seconds</div>
        </div>
      `;
    }

    try {
      const questions = await AIService.generateQuiz({ topic, content, count, difficulty, quizType: type });

      const quiz = DB.Quizzes.create({
        title: `${topic} — ${type.toUpperCase()} (${difficulty})`,
        documentIds: docId ? [docId] : [],
        questions,
        settings: { count, difficulty, type, topic },
      });

      UsageService.incrementUsage('quiz_generations_per_month');
      this.currentQuiz = quiz;
      this.startQuiz(quiz);
      Toast.success(`${questions.length} questions generated!`);
    } catch (err) {
      if (quizArea) {
        quizArea.innerHTML = `
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
            <div style="font-size:48px;">⚠️</div>
            <div style="font-size:15px;font-weight:600;color:var(--brand-danger);">Generation Failed</div>
            <div style="font-size:13px;color:var(--text-muted);text-align:center;max-width:400px;">${err.message}</div>
            <button class="btn btn-outline" onclick="QuizPage.generateQuiz()">↻ Try Again</button>
          </div>
        `;
      }
      Toast.error('Quiz generation failed: ' + err.message);
    }
  },

  startSavedQuiz(id) {
    const quiz = DB.Quizzes.get(id);
    if (!quiz) return;
    this.currentQuiz = quiz;
    this.startQuiz(quiz);
  },

  startQuiz(quiz) {
    this.currentQ = 0;
    this.answers = {};
    this.submitted = false;
    this.timeLeft = quiz.questions.length * 60; // 1 min per question

    clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.timeLeft--;
      this.updateTimer();
      if (this.timeLeft <= 0) {
        clearInterval(this.timerInterval);
        if (!this.submitted) this.submitQuiz();
      }
    }, 1000);

    this.renderQuizPlayer();
  },

  renderQuizPlayer() {
    const quiz = this.currentQuiz;
    if (!quiz) return;
    const q = quiz.questions[this.currentQ];
    const totalQ = quiz.questions.length;

    const quizArea = document.getElementById('quiz-area');
    if (!quizArea) return;

    const mins = Math.floor(this.timeLeft / 60);
    const secs = this.timeLeft % 60;
    const timeStr = `${mins}:${secs.toString().padStart(2,'0')}`;
    const timerClass = this.timeLeft < 60 ? 'danger' : this.timeLeft < 180 ? 'warning' : '';

    quizArea.innerHTML = `
      <!-- Quiz Header -->
      <div class="quiz-header">
        <div style="display:flex;gap:8px;align-items:center;flex:1;">
          <div style="font-size:13px;color:var(--text-muted);">${quiz.title}</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span style="font-size:13px;color:var(--text-muted);">Q ${this.currentQ+1}/${totalQ}</span>
          <div class="quiz-timer ${timerClass}" id="quiz-timer">⏱ ${timeStr}</div>
        </div>
        <button class="btn btn-ghost btn-sm" onclick="QuizPage.submitQuiz()">Submit Quiz</button>
      </div>

      <!-- Progress -->
      <div class="progress-bar" style="margin-bottom:20px;">
        <div class="progress-fill" style="width:${((this.currentQ+1)/totalQ*100).toFixed(1)}%"></div>
      </div>

      <!-- Question -->
      <div class="quiz-question-card">
        <div class="quiz-question-number">Question ${this.currentQ+1} of ${totalQ} · ${q.difficulty || 'medium'} · ${q.topic || 'General'}</div>
        <div class="quiz-question-text">${q.question}</div>
        <div class="quiz-options" id="quiz-options">
          ${this.renderOptions(q)}
        </div>
        ${this.submitted && this.answers[this.currentQ] !== undefined ? this.renderExplanation(q) : ''}
      </div>

      <!-- Navigation -->
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <button class="btn btn-outline" onclick="QuizPage.prevQuestion()" ${this.currentQ === 0 ? 'disabled' : ''}>← Previous</button>
        <div style="display:flex;gap:4px;">
          ${quiz.questions.map((_, i) => `
            <button class="exam-q-btn ${i === this.currentQ ? 'current' : this.answers[i] !== undefined ? 'answered' : ''}"
                    onclick="QuizPage.goToQuestion(${i})">${i+1}</button>
          `).join('')}
        </div>
        ${this.currentQ < totalQ - 1
          ? `<button class="btn btn-primary" onclick="QuizPage.nextQuestion()">Next →</button>`
          : `<button class="btn btn-success" onclick="QuizPage.submitQuiz()">Submit Quiz ✓</button>`
        }
      </div>
    `;
  },

  renderOptions(q) {
    const selectedAnswer = this.answers[this.currentQ];
    const optionLetters = ['A','B','C','D','E'];

    if (!q.options) {
      // Short answer / fill-blanks
      return `
        <textarea class="form-textarea" id="short-answer" rows="3"
                  placeholder="Type your answer here…"
                  onchange="QuizPage.selectAnswer(this.value)">${selectedAnswer || ''}</textarea>
      `;
    }

    return q.options.map((opt, i) => {
      let cls = '';
      if (this.submitted && selectedAnswer !== undefined) {
        if (i === q.correct) cls = 'correct';
        else if (i === selectedAnswer && i !== q.correct) cls = 'incorrect';
      } else if (selectedAnswer === i) cls = 'selected';
      return `
        <button class="quiz-option ${cls}" onclick="QuizPage.selectAnswer(${i})" ${this.submitted ? 'disabled' : ''}>
          <span class="quiz-option-letter">${optionLetters[i]}</span>
          <span>${opt}</span>
        </button>
      `;
    }).join('');
  },

  renderExplanation(q) {
    const correct = this.answers[this.currentQ] === q.correct;
    return `
      <div class="quiz-explanation">
        <div class="quiz-explanation-title">${correct ? '✓ Correct!' : '✕ Incorrect'}</div>
        <div class="quiz-explanation-text"><strong>Explanation:</strong> ${q.explanation || 'No explanation provided.'}</div>
      </div>
    `;
  },

  selectAnswer(answer) {
    if (this.submitted) return;
    this.answers[this.currentQ] = answer;
    this.renderQuizPlayer();
  },

  nextQuestion() {
    if (this.currentQ < this.currentQuiz.questions.length - 1) {
      this.currentQ++;
      this.renderQuizPlayer();
    }
  },

  prevQuestion() {
    if (this.currentQ > 0) {
      this.currentQ--;
      this.renderQuizPlayer();
    }
  },

  goToQuestion(index) {
    this.currentQ = index;
    this.renderQuizPlayer();
  },

  updateTimer() {
    const timerEl = document.getElementById('quiz-timer');
    if (!timerEl) return;
    const mins = Math.floor(this.timeLeft / 60);
    const secs = this.timeLeft % 60;
    timerEl.textContent = `⏱ ${mins}:${secs.toString().padStart(2,'0')}`;
    timerEl.className = `quiz-timer ${this.timeLeft < 60 ? 'danger' : this.timeLeft < 180 ? 'warning' : ''}`;
  },

  submitQuiz() {
    clearInterval(this.timerInterval);
    this.submitted = true;
    const quiz = this.currentQuiz;
    const total = quiz.questions.length;
    const answered = Object.keys(this.answers).length;
    let correct = 0;
    const incorrectQs = [];

    quiz.questions.forEach((q, i) => {
      const ans = this.answers[i];
      if (q.options && ans === q.correct) correct++;
      else if (!q.options && ans) correct++; // partial credit for short answers
      else incorrectQs.push({ ...q, index: i, userAnswer: ans });
    });

    const score = Math.round((correct / total) * 100);
    const timeTaken = quiz.questions.length * 60 - this.timeLeft;

    DB.Quizzes.saveAttempt({
      quizId: quiz.id,
      answers: this.answers,
      score,
      timeTaken,
      incorrectQuestions: incorrectQs,
    });

    this.renderResults(score, correct, total, timeTaken, incorrectQs);
  },

  renderResults(score, correct, total, timeTaken, incorrectQs) {
    const quizArea = document.getElementById('quiz-area');
    if (!quizArea) return;
    const color = score >= 80 ? 'var(--brand-success)' : score >= 60 ? 'var(--brand-accent)' : 'var(--brand-danger)';
    const emoji = score >= 80 ? '🏆' : score >= 60 ? '👍' : '📚';

    quizArea.innerHTML = `
      <div class="card" style="text-align:center;padding:40px;">
        <div style="font-size:64px;margin-bottom:16px;" class="score-reveal">${emoji}</div>
        <h2 style="font-size:48px;font-weight:900;color:${color};margin-bottom:8px;" class="score-reveal">${score}%</h2>
        <div style="font-size:16px;color:var(--text-muted);margin-bottom:32px;">${correct} of ${total} correct · ${Helpers.formatDuration(Math.round(timeTaken/60))}</div>

        <div class="grid grid-3" style="margin-bottom:32px;gap:16px;">
          <div class="stat-card">
            <div style="font-size:24px;font-weight:800;color:var(--brand-success);">${correct}</div>
            <div style="font-size:13px;color:var(--text-muted);">Correct</div>
          </div>
          <div class="stat-card">
            <div style="font-size:24px;font-weight:800;color:var(--brand-danger);">${total - correct}</div>
            <div style="font-size:13px;color:var(--text-muted);">Incorrect</div>
          </div>
          <div class="stat-card">
            <div style="font-size:24px;font-weight:800;color:var(--brand-accent);">${total - Object.keys(this.answers).length}</div>
            <div style="font-size:13px;color:var(--text-muted);">Unattempted</div>
          </div>
        </div>

        ${incorrectQs.length > 0 ? `
          <div style="text-align:left;margin-bottom:24px;">
            <h3 style="font-size:16px;font-weight:700;margin-bottom:12px;">Topics to Review:</h3>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
              ${[...new Set(incorrectQs.map(q => q.topic || 'General'))].map(t =>
                `<span class="badge badge-danger">⚡ ${t}</span>`
              ).join('')}
            </div>
          </div>
        ` : ''}

        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
          <button class="btn btn-outline" onclick="QuizPage.startQuiz(QuizPage.currentQuiz)">↻ Retake Quiz</button>
          <button class="btn btn-primary" onclick="QuizPage.render()">+ New Quiz</button>
          <a href="#/progress" class="btn btn-ghost">📊 View Progress</a>
        </div>
      </div>
    `;
  },
};

/**
 * StudyMate AI — AI Chat Page
 * Full RAG-powered chat interface with conversation management.
 */
window.AIChatPage = {
  currentConvId: null,
  currentMode: 'detailed',
  selectedDocs: [],
  selectedSubject: null,
  isLoading: false,

  render(params = {}) {
    const root = document.getElementById('app-root');
    const convs = DB.Conversations.list();
    const subjects = DB.Subjects.list();
    const docs = DB.Documents.list().filter(d => d.status === 'ready');

    if (params.id) this.currentConvId = params.id;
    if (params.docId) this.selectedDocs = [params.docId];

    root.innerHTML = `
      <div class="app-layout">
        ${SidebarComponent.render()}
        <div id="mobile-backdrop" class="mobile-backdrop" onclick="SidebarComponent.closeMobile()"></div>

        <div class="main-content ${SidebarComponent.sidebarCollapsed ? 'sidebar-collapsed' : ''}" id="main-content">
          <!-- Topbar -->
          <header class="topbar ${SidebarComponent.sidebarCollapsed ? 'sidebar-collapsed' : ''}" id="app-topbar">
            <button class="hamburger-btn" onclick="SidebarComponent.openMobile()"><span></span><span></span><span></span></button>
            <div class="topbar-breadcrumb">
              <span class="topbar-breadcrumb-current">AI Study Chat</span>
            </div>
            <div class="topbar-spacer"></div>
            <div class="topbar-actions">
              <button class="btn btn-icon btn-ghost" onclick="AppShell.toggleTheme()">◑</button>
            </div>
          </header>

          <!-- Chat Layout -->
          <div class="chat-layout" style="height:calc(100vh - var(--topbar-height));">
            <!-- Chat Sidebar -->
            <div class="chat-sidebar">
              <div class="chat-sidebar-header">
                <button class="btn btn-primary w-full" onclick="AIChatPage.newChat()" style="width:100%;">
                  + New Chat
                </button>
              </div>

              <div class="chat-list" id="chat-list">
                ${convs.length === 0
                  ? `<div style="padding:16px;text-align:center;color:var(--text-muted);font-size:13px;">Start a new chat to begin studying</div>`
                  : convs.map(c => `
                    <div class="chat-list-item ${this.currentConvId === c.id ? 'active' : ''}" onclick="AIChatPage.loadChat('${c.id}')">
                      <div class="chat-list-item-title">${Helpers.truncate(c.title, 30)}</div>
                      <div style="display:flex;align-items:center;justify-content:space-between;width:100%;">
                        <div class="chat-list-item-time">${Helpers.timeAgo(c.updatedAt)}</div>
                        <div class="chat-list-item-actions">
                          <button class="btn btn-icon-sm btn-ghost" onclick="event.stopPropagation();AIChatPage.renameChat('${c.id}')" title="Rename">✏</button>
                          <button class="btn btn-icon-sm btn-ghost" onclick="event.stopPropagation();AIChatPage.deleteChat('${c.id}')" title="Delete" style="color:var(--brand-danger);">🗑</button>
                        </div>
                      </div>
                    </div>
                  `).join('')
                }
              </div>
            </div>

            <!-- Chat Main -->
            <div class="chat-main">
              <!-- Chat Header -->
              <div class="chat-header">
                <div class="chat-context-selector">
                  <span style="font-size:12px;color:var(--text-muted);font-weight:500;">Context:</span>
                  <div class="chat-context-tag ${!this.selectedSubject && this.selectedDocs.length === 0 ? 'active' : ''}"
                       onclick="AIChatPage.setContext('all')">
                    📚 All Documents
                  </div>
                  ${subjects.slice(0, 3).map(s => `
                    <div class="chat-context-tag ${this.selectedSubject === s.id ? 'active' : ''}"
                         onclick="AIChatPage.setContext('subject', '${s.id}')">
                      ${Helpers.truncate(s.name, 15)}
                    </div>
                  `).join('')}
                  ${docs.length > 0 ? `
                    <button class="btn btn-sm btn-ghost" style="font-size:12px;" onclick="AIChatPage.showDocSelector()">📄 Select Doc</button>
                  ` : ''}
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                  <span style="font-size:12px;color:var(--text-muted);">${docs.length} docs indexed</span>
                  <a href="#/documents" class="btn btn-sm btn-ghost">+ Upload</a>
                </div>
              </div>

              <!-- Mode Bar -->
              <div class="chat-mode-bar">
                <span style="font-size:11px;color:var(--text-muted);white-space:nowrap;margin-right:4px;">Mode:</span>
                ${[
                  {key:'simple', label:'💡 Simple'},
                  {key:'detailed', label:'📖 Detailed'},
                  {key:'exam', label:'🎯 Exam Answer'},
                  {key:'revision', label:'⚡ Quick Revision'},
                  {key:'beginner', label:'🌱 Beginner'},
                  {key:'technical', label:'🔬 Technical'},
                ].map(m => `
                  <button class="mode-chip ${this.currentMode === m.key ? 'active' : ''}"
                          onclick="AIChatPage.setMode('${m.key}')">
                    ${m.label}
                  </button>
                `).join('')}
              </div>

              <!-- Messages -->
              <div class="chat-messages" id="chat-messages">
                ${this.currentConvId ? this.renderMessages() : this.renderWelcome()}
              </div>

              <!-- Input Area -->
              <div class="chat-input-area">
                ${!AIService.isConfigured() ? `
                  <div class="alert alert-warning" style="margin-bottom:12px;">
                    <span class="alert-icon">⚙️</span>
                    <div>
                      <strong>AI not configured.</strong> Please add your Gemini API key in 
                      <a href="#/profile?tab=settings">Settings</a> to enable AI chat.
                    </div>
                  </div>
                ` : ''}
                <div class="chat-input-box">
                  <textarea class="chat-textarea" id="chat-input" rows="1"
                            placeholder="Ask anything about your study material…"
                            onkeydown="AIChatPage.handleKeyDown(event)"
                            oninput="AIChatPage.autoResize(this)"
                            ${!AIService.isConfigured() ? 'disabled' : ''}></textarea>
                  <button class="btn btn-icon btn-primary" id="send-btn"
                          onclick="AIChatPage.sendMessage()"
                          ${!AIService.isConfigured() ? 'disabled' : ''}
                          title="Send message">→</button>
                </div>
                <div class="ai-disclaimer">
                  <span class="ai-disclaimer-icon">⚠</span>
                  AI-generated answers — verify important information before exams
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  renderWelcome() {
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    return `
      <div class="empty-state" style="padding:48px 24px;">
        <div style="font-size:64px;margin-bottom:16px;">🤖</div>
        <div class="empty-state-title">StudyMate AI is ready</div>
        <div class="empty-state-desc" style="margin-bottom:24px;">
          ${docs.length === 0
            ? 'Upload study material first, then ask questions from it.'
            : `${docs.length} document${docs.length !== 1 ? 's' : ''} indexed. Ask anything about your study material.`
          }
        </div>
        ${docs.length === 0 ? `<a href="#/documents" class="btn btn-primary">⬆️ Upload Documents First</a>` : ''}
        <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:16px;max-width:500px;">
          ${[
            'Explain normalization in DBMS',
            'What is the time complexity of quicksort?',
            'Summarize Unit 2 of my notes',
            'Generate MCQs from this topic',
            'What topics are in the syllabus?',
          ].map(q => `
            <button class="follow-up-chip" onclick="AIChatPage.fillInput('${q}')">${q}</button>
          `).join('')}
        </div>
      </div>
    `;
  },

  renderMessages() {
    const conv = DB.Conversations.get(this.currentConvId);
    if (!conv) return this.renderWelcome();
    const messages = DB.Conversations.getMessages(this.currentConvId);
    if (messages.length === 0) return this.renderWelcome();

    return messages.map(msg => this.renderMessage(msg)).join('');
  },

  renderMessage(msg) {
    if (msg.role === 'user') {
      return `
        <div class="chat-message chat-message-user animate-fade-in-up">
          <div style="width:32px;height:32px;border-radius:50%;background:var(--brand-primary);display:flex;align-items:center;justify-content:center;font-size:14px;color:white;flex-shrink:0;">
            ${Helpers.getInitials(AuthService.getCurrentUser()?.name || 'U')}
          </div>
          <div>
            <div class="chat-bubble chat-bubble-user">${Helpers.escapeHtml(msg.content)}</div>
            <div class="chat-meta chat-meta-user">${Helpers.timeAgo(msg.createdAt)}</div>
          </div>
        </div>
      `;
    } else {
      const hasContext = msg.sources && msg.sources.length > 0;
      return `
        <div class="chat-message animate-fade-in-up" id="msg-${msg.id}">
          <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#4F46E5,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">🤖</div>
          <div style="flex:1;min-width:0;">
            <div class="chat-bubble chat-bubble-ai">
              <div style="font-size:14px;line-height:1.7;white-space:pre-wrap;">${msg.content}</div>
              ${hasContext ? `
                <div class="source-refs">
                  <div class="source-refs-label">📚 Sources used:</div>
                  ${msg.sources.map(s => `
                    <span class="source-chip">📄 ${Helpers.truncate(s.documentName, 25)}${s.pageNumber ? ` · p.${s.pageNumber}` : ''}</span>
                  `).join('')}
                </div>
              ` : ''}
            </div>
            <div class="chat-meta" style="display:flex;gap:8px;align-items:center;margin-top:6px;">
              <span>${Helpers.timeAgo(msg.createdAt)}</span>
              <button class="btn btn-sm btn-ghost" style="padding:2px 8px;font-size:11px;" onclick="Helpers.copyToClipboard(${JSON.stringify(msg.content)})">⧉ Copy</button>
              <button class="btn btn-sm btn-ghost" style="padding:2px 8px;font-size:11px;" onclick="AIChatPage.fillInput('Explain more simply')">💡 Simplify</button>
              <button class="btn btn-sm btn-ghost" style="padding:2px 8px;font-size:11px;" onclick="AIChatPage.fillInput('Give an exam-ready answer')">🎯 Exam Answer</button>
            </div>
            <div class="follow-up-row">
              ${['Give an example','Make MCQs from this','Create flashcards from this','Explain the key points'].map(s =>
                `<button class="follow-up-chip" onclick="AIChatPage.fillInput('${s}')">${s}</button>`
              ).join('')}
            </div>
          </div>
        </div>
      `;
    }
  },

  renderTypingIndicator() {
    return `
      <div class="chat-message" id="typing-indicator">
        <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#4F46E5,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">🤖</div>
        <div class="chat-bubble chat-bubble-ai">
          <div class="ai-typing">
            <div class="ai-typing-dot"></div>
            <div class="ai-typing-dot"></div>
            <div class="ai-typing-dot"></div>
          </div>
        </div>
      </div>
    `;
  },

  fillInput(text) {
    const input = document.getElementById('chat-input');
    if (input) { input.value = text; input.focus(); }
  },

  handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.sendMessage();
    }
  },

  autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
  },

  setMode(mode) {
    this.currentMode = mode;
    document.querySelectorAll('.mode-chip').forEach(c => c.classList.remove('active'));
    const chips = document.querySelectorAll('.mode-chip');
    const modes = ['simple','detailed','exam','revision','beginner','technical'];
    const idx = modes.indexOf(mode);
    if (chips[idx]) chips[idx].classList.add('active');
  },

  setContext(type, id = null) {
    if (type === 'all') { this.selectedSubject = null; this.selectedDocs = []; }
    else if (type === 'subject') { this.selectedSubject = id; this.selectedDocs = []; }
    else if (type === 'doc') { this.selectedDocs = [id]; this.selectedSubject = null; }
    document.querySelectorAll('.chat-context-tag').forEach(t => t.classList.remove('active'));
    // Re-render header context selector
    Toast.info(`Context set to ${type === 'all' ? 'all documents' : type === 'subject' ? 'selected subject' : 'specific document'}`);
  },

  newChat() {
    this.currentConvId = null;
    this.render();
  },

  loadChat(id) {
    this.currentConvId = id;
    const messages = document.getElementById('chat-messages');
    const chatList = document.getElementById('chat-list');
    if (messages) messages.innerHTML = this.renderMessages();
    if (chatList) {
      chatList.querySelectorAll('.chat-list-item').forEach(el => {
        el.classList.toggle('active', el.getAttribute('onclick').includes(id));
      });
    }
    this.scrollToBottom();
  },

  renameChat(id) {
    const conv = DB.Conversations.get(id);
    if (!conv) return;
    const newTitle = prompt('Rename chat:', conv.title);
    if (newTitle?.trim()) {
      DB.Conversations.update(id, { title: newTitle.trim() });
      this.render();
      Toast.success('Chat renamed');
    }
  },

  deleteChat(id) {
    Modal.confirm('Delete this chat? All messages will be lost.', () => {
      DB.Conversations.delete(id);
      if (this.currentConvId === id) this.currentConvId = null;
      this.render();
      Toast.success('Chat deleted');
    }, { title: 'Delete Chat', confirmText: 'Delete', danger: true });
  },

  async sendMessage() {
    const input = document.getElementById('chat-input');
    const question = input?.value?.trim();
    if (!question || this.isLoading) return;

    // Usage check
    const limitResult = UsageService.checkLimit('ai_questions_per_month');
    if (!limitResult.allowed) {
      UpgradeModal.show('ai_questions_per_month', limitResult);
      return;
    }

    if (!AIService.isConfigured()) {
      Toast.error('Please configure your AI API key in Settings first.');
      return;
    }

    this.isLoading = true;
    input.value = '';
    input.style.height = 'auto';

    // Create conversation if needed
    if (!this.currentConvId) {
      const conv = DB.Conversations.create({
        title: question.slice(0, 60) + (question.length > 60 ? '…' : ''),
        subjectId: this.selectedSubject,
        documentIds: this.selectedDocs,
        mode: this.currentMode,
      });
      this.currentConvId = conv.id;
    }

    // Add user message
    DB.Conversations.addMessage({
      conversationId: this.currentConvId,
      role: 'user',
      content: question,
    });

    // Show messages
    const messagesEl = document.getElementById('chat-messages');
    if (messagesEl) {
      const msgs = DB.Conversations.getMessages(this.currentConvId);
      messagesEl.innerHTML = msgs.map(m => this.renderMessage(m)).join('') + this.renderTypingIndicator();
      this.scrollToBottom();
    }

    const sendBtn = document.getElementById('send-btn');
    if (sendBtn) { sendBtn.disabled = true; sendBtn.textContent = '…'; }

    try {
      // RAG retrieval
      const chunks = RAGEngine.retrieve({
        query: question,
        documentIds: this.selectedDocs.length > 0 ? this.selectedDocs : null,
        subjectId: this.selectedSubject,
      });

      const sources = RAGEngine.formatSources(chunks);

      // Get conversation history
      const allMsgs = DB.Conversations.getMessages(this.currentConvId);
      const history = allMsgs.slice(-8, -1).map(m => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.content,
      }));

      // Subject context
      const subject = this.selectedSubject ? DB.Subjects.get(this.selectedSubject) : null;
      const subjectContext = subject ? `${subject.name} (${subject.code || ''} · ${subject.semester || ''})` : '';

      // Call AI
      const result = await AIService.ragChat({
        question,
        retrievedChunks: chunks,
        conversationHistory: history,
        mode: this.currentMode,
        subjectContext,
      });

      // Save AI response
      DB.Conversations.addMessage({
        conversationId: this.currentConvId,
        role: 'assistant',
        content: result.text,
        sources,
        mode: this.currentMode,
      });

      // Track usage
      UsageService.incrementUsage('ai_questions_per_month');

      // Update UI
      const typing = document.getElementById('typing-indicator');
      if (typing) typing.remove();
      const newMsgs = DB.Conversations.getMessages(this.currentConvId);
      if (messagesEl) {
        messagesEl.innerHTML = newMsgs.map(m => this.renderMessage(m)).join('');
        this.scrollToBottom();
      }
    } catch (err) {
      const typing = document.getElementById('typing-indicator');
      if (typing) typing.remove();

      let userMsg = err.message;
      if (err.message === 'AI_NOT_CONFIGURED') {
        userMsg = 'Please add your AI API key in Settings to use this feature.';
      }

      if (messagesEl) {
        messagesEl.insertAdjacentHTML('beforeend', `
          <div class="alert alert-danger" style="margin:8px 0;" id="ai-error-msg">
            <span class="alert-icon">⚠</span>
            <div>
              <strong>AI request failed.</strong> ${userMsg}
              <button class="btn btn-sm btn-ghost" onclick="document.getElementById('ai-error-msg').remove();document.getElementById('chat-input').value='${question.replace(/'/g, "\\'")}'" style="margin-left:8px;">↻ Retry</button>
            </div>
          </div>
        `);
      }
      Toast.error('AI request failed: ' + userMsg);
    } finally {
      this.isLoading = false;
      if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = '→'; }
      if (input) input.focus();
    }
  },

  scrollToBottom() {
    setTimeout(() => {
      const el = document.getElementById('chat-messages');
      if (el) el.scrollTop = el.scrollHeight;
    }, 100);
  },

  showDocSelector() {
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    Modal.show(`
      <div class="modal-header">
        <h3 class="modal-title">Select Document Context</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">AI will search only within the selected document.</p>
        <div style="display:flex;flex-direction:column;gap:8px;">
          ${docs.map(d => `
            <div class="doc-item" onclick="AIChatPage.setContext('doc','${d.id}');Modal.close();" style="cursor:pointer;">
              <div class="doc-icon doc-icon-pdf">📑</div>
              <div class="doc-info">
                <div class="doc-name">${d.name}</div>
                <div class="doc-meta">${d.chunkCount || 0} chunks · ${Helpers.fileSize(d.fileSize)}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `, { size: '' });
  },
};

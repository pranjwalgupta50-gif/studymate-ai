/**
 * StudyMate AI — AI Service
 * Handles all AI API communication.
 *
 * SECURITY NOTE:
 * In production, API keys MUST go through a server-side proxy.
 * The frontend NEVER calls the AI API directly with a secret key.
 * This demo allows a user-provided key stored in localStorage (dev mode only).
 *
 * In production, replace callAI() with a call to your backend:
 *   POST /api/ai/chat  { messages, context, mode, userId }
 *
 * Supports: Gemini API (Google), OpenAI API (configurable via env)
 */

window.AIService = (() => {
  let lastRequestTime = 0;

  function getApiKey() {
    return localStorage.getItem(AppConfig.AI.KEY_STORAGE) || '';
  }

  function isConfigured() {
    return !!getApiKey();
  }

  // ---- Rate limiting (client-side UX only) ----
  function checkRateLimit() {
    const now = Date.now();
    const elapsed = now - lastRequestTime;
    if (elapsed < AppConfig.RATE_LIMIT.AI_REQUEST_COOLDOWN_MS) {
      return {
        allowed: false,
        waitMs: AppConfig.RATE_LIMIT.AI_REQUEST_COOLDOWN_MS - elapsed,
      };
    }
    return { allowed: true };
  }

  // ---- Core AI call ----
  async function callAI({ messages, systemPrompt, maxTokens = 4096, temperature = 0.7 }) {
    if (!isConfigured()) {
      throw new Error('AI_NOT_CONFIGURED');
    }

    const rateCheck = checkRateLimit();
    if (!rateCheck.allowed) {
      await new Promise(r => setTimeout(r, rateCheck.waitMs));
    }

    lastRequestTime = Date.now();
    const apiKey = getApiKey();
    const provider = AppConfig.AI.PROVIDER;

    if (provider === 'gemini') {
      return await callGemini({ messages, systemPrompt, maxTokens, temperature, apiKey });
    } else if (provider === 'openai') {
      return await callOpenAI({ messages, systemPrompt, maxTokens, temperature, apiKey });
    }
    throw new Error('Unknown AI provider: ' + provider);
  }

  async function callGemini({ messages, systemPrompt, maxTokens, temperature, apiKey }) {
    const model = AppConfig.AI.MODEL;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    // Build Gemini content format
    const contents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const body = {
      contents,
      systemInstruction: systemPrompt ? { parts: [{ text: systemPrompt }] } : undefined,
      generationConfig: {
        maxOutputTokens: maxTokens,
        temperature,
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
      ],
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      if (response.status === 403 || response.status === 401) {
        throw new Error('Invalid API key. Please check your Gemini API key in Settings.');
      }
      if (response.status === 429) {
        throw new Error('API rate limit reached. Please wait a moment and try again.');
      }
      throw new Error(err?.error?.message || `AI API error (${response.status})`);
    }

    const data = await response.json();
    const candidate = data.candidates?.[0];
    if (!candidate) throw new Error('No response from AI. Please try again.');
    if (candidate.finishReason === 'SAFETY') throw new Error('Response blocked by safety filter.');

    return candidate.content?.parts?.[0]?.text || '';
  }

  async function callOpenAI({ messages, systemPrompt, maxTokens, temperature, apiKey }) {
    const allMessages = [];
    if (systemPrompt) allMessages.push({ role: 'system', content: systemPrompt });
    allMessages.push(...messages);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: allMessages,
        max_tokens: maxTokens,
        temperature,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      if (response.status === 401) throw new Error('Invalid OpenAI API key. Please check Settings.');
      if (response.status === 429) throw new Error('OpenAI rate limit reached. Please wait and retry.');
      throw new Error(err?.error?.message || `AI API error (${response.status})`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || '';
  }

  // ---- Study Mode prompts ----
  const MODE_PROMPTS = {
    simple: 'Explain this in simple, clear language suitable for a first-year student.',
    detailed: 'Provide a thorough, detailed explanation with examples.',
    exam: 'Provide an exam-ready answer with key points, definitions, and structured content.',
    revision: 'Give a quick revision summary with the most important points.',
    beginner: 'Explain this as if talking to a complete beginner. Use analogies and simple words.',
    technical: 'Provide a technical, precise explanation suitable for exam preparation.',
  };

  // ---- RAG Chat ----
  async function ragChat({ question, retrievedChunks, conversationHistory = [], mode = 'detailed', subjectContext = '' }) {
    const hasContext = retrievedChunks && retrievedChunks.length > 0;

    const contextText = hasContext
      ? retrievedChunks.map((c, i) =>
          `[Source ${i+1}: ${c.documentName}${c.pageNumber ? `, Page ${c.pageNumber}` : ''}]\n${c.text}`
        ).join('\n\n---\n\n')
      : '';

    const systemPrompt = `You are StudyMate AI, an intelligent study assistant for Indian college and university students.
You help students understand their academic material (syllabus, notes, textbooks, PYQs).

${subjectContext ? `Current subject context: ${subjectContext}` : ''}

CRITICAL RULES:
1. Base your answers PRIMARILY on the provided source context when available.
2. Clearly distinguish between information from uploaded sources vs. general knowledge.
3. NEVER fabricate page numbers, citations, or references.
4. If the context doesn't contain enough information, explicitly say so.
5. Use Indian academic terminology: semester, unit, module, subject, PYQ, internal exam, end-semester exam.
6. ${MODE_PROMPTS[mode] || MODE_PROMPTS.detailed}
7. Structure answers with headings, bullet points, and examples where appropriate.
8. At the end of your answer, add a brief "📚 Source Coverage" note indicating whether your answer is fully, partially, or not covered by the uploaded material.
9. Never claim a topic "will definitely appear in the exam." Use careful language.
10. Add "⚠️ AI-generated — verify important information before exams." at the very end.

${hasContext
  ? `UPLOADED MATERIAL CONTEXT:\n${contextText}`
  : `NO RELEVANT CONTEXT FOUND: The uploaded documents don't appear to contain specific information about this question. You may provide a general answer but must clearly state this is general knowledge, not from the student's uploaded material.`
}`;

    const messages = [
      ...conversationHistory.slice(-10), // last 5 exchanges
      { role: 'user', content: question },
    ];

    const text = await callAI({ messages, systemPrompt, maxTokens: 2048, temperature: 0.6 });
    return { text, sources: retrievedChunks };
  }

  // ---- Notes Generator ----
  async function generateNotes({ topic, content, noteType = 'detailed', subjectName = '' }) {
    const typePrompts = {
      quick:    'Create concise quick notes with bullet points and key terms.',
      detailed: 'Create comprehensive detailed notes with headings, sub-topics, definitions, examples, and key formulas.',
      exam:     'Create exam-focused notes highlighting the most important definitions, concepts, and likely exam questions.',
      revision: 'Create a revision summary with the absolute most critical points a student must remember.',
    };

    const systemPrompt = `You are StudyMate AI, generating academic notes for Indian college students.
Subject: ${subjectName}
Note Type: ${noteType}

Generate well-structured academic notes in the following HTML format:
- Use <h2> for main topics
- Use <h3> for sub-topics
- Use <ul>/<li> for lists
- Wrap key definitions in: <div class="definition-box"><strong>Term:</strong> Definition</div>
- Wrap important points in: <div class="key-point">⭐ Important: ...</div>
- Use <strong> for emphasis
- Add a "Key Takeaways" section at the end

${typePrompts[noteType] || typePrompts.detailed}

Always add: <p class="ai-note" style="color:#94A3B8;font-size:13px;margin-top:24px;">⚠️ AI-generated notes — verify with your textbook and official study material.</p>`;

    const messages = [{ role: 'user', content: `Generate notes for: ${topic}\n\nSource material:\n${content.slice(0, 8000)}` }];
    return await callAI({ messages, systemPrompt, maxTokens: 3000, temperature: 0.5 });
  }

  // ---- Quiz Generator ----
  async function generateQuiz({ topic, content, count = 10, difficulty = 'medium', quizType = 'mcq' }) {
    const typeInstructions = {
      mcq: `Generate ${count} multiple-choice questions (MCQ) with 4 options (A, B, C, D).`,
      truefalse: `Generate ${count} True/False questions.`,
      short: `Generate ${count} short-answer questions (1-3 sentence answers).`,
      fillblanks: `Generate ${count} fill-in-the-blank questions.`,
    };

    const systemPrompt = `You are StudyMate AI, generating quiz questions for Indian college students.
${typeInstructions[quizType] || typeInstructions.mcq}
Difficulty: ${difficulty} (easy/medium/hard)
Topic: ${topic}

IMPORTANT: Return ONLY a valid JSON array. No markdown, no explanation. Format:
[
  {
    "id": "q1",
    "question": "Question text here?",
    "type": "${quizType}",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correct": 0,
    "explanation": "Why this answer is correct",
    "topic": "sub-topic name",
    "difficulty": "${difficulty}"
  }
]
For True/False: options = ["True", "False"], correct = 0 or 1
For short-answer: options = null, correct = 0, explanation = model answer
For fill-blanks: use ___ in question, options = null, explanation = answer
Make questions clear, unambiguous, and based on the provided content.
Do not repeat questions.`;

    const messages = [{ role: 'user', content: `Generate quiz from: ${topic}\n\nSource:\n${content.slice(0, 6000)}` }];
    const raw = await callAI({ messages, systemPrompt, maxTokens: 3000, temperature: 0.7 });

    // Parse JSON from response
    const jsonMatch = raw.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error('AI returned invalid quiz format. Please try again.');

    const questions = JSON.parse(jsonMatch[0]);
    if (!Array.isArray(questions) || questions.length === 0) {
      throw new Error('No valid questions generated. Please try with different source material.');
    }

    return questions.slice(0, count);
  }

  // ---- Flashcard Generator ----
  async function generateFlashcards({ topic, content, count = 15 }) {
    const systemPrompt = `You are StudyMate AI, generating flashcards for Indian college students.
Generate exactly ${count} flashcards from the provided content.
Return ONLY a valid JSON array:
[
  {
    "id": "fc1",
    "front": "Question or term (keep concise, max 100 chars)",
    "back": "Answer or definition (keep concise, max 200 chars)"
  }
]
Cover key definitions, concepts, formulas, and important facts.
Make each card focused on a single concept.`;

    const messages = [{ role: 'user', content: `Generate flashcards for: ${topic}\n\nSource:\n${content.slice(0, 6000)}` }];
    const raw = await callAI({ messages, systemPrompt, maxTokens: 2000, temperature: 0.6 });

    const jsonMatch = raw.match(/\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error('AI returned invalid flashcard format.');
    const cards = JSON.parse(jsonMatch[0]);
    return cards.slice(0, count).map((c, i) => ({
      ...c,
      id: StorageService.generateId('fc_'),
      difficulty: 'normal',
      learned: false,
      lastReviewed: null,
    }));
  }

  // ---- PYQ Analysis ----
  async function analyzePYQs({ papersContent, subject, course }) {
    const systemPrompt = `You are StudyMate AI, analyzing previous year question papers for Indian college students.
Subject: ${subject}
Course: ${course}

Analyze the provided question papers and return ONLY a valid JSON object:
{
  "topics": [
    {
      "name": "Topic name",
      "frequency": 4,
      "years": ["2022", "2023"],
      "classification": "frequently_asked",
      "questions": ["Sample question 1", "Sample question 2"]
    }
  ],
  "patterns": {
    "totalQuestions": 50,
    "uniqueTopics": 15,
    "mostFrequentTopics": ["Topic A", "Topic B", "Topic C"],
    "yearwiseCount": {"2022": 12, "2023": 15}
  },
  "questionBank": [
    {
      "id": "pyq1",
      "question": "Question text",
      "year": "2023",
      "unit": "Unit 1",
      "topic": "Topic name",
      "marks": null,
      "type": "theory"
    }
  ]
}

Classification values: "frequently_asked" | "repeated_recently" | "appeared_occasionally" | "less_frequently_seen"
IMPORTANT: Only report what you actually find in the papers. Do not invent statistics or claim a topic "will appear in the exam."`;

    const messages = [{ role: 'user', content: `Analyze these question papers:\n\n${papersContent.slice(0, 10000)}` }];
    const raw = await callAI({ messages, systemPrompt, maxTokens: 3000, temperature: 0.3 });

    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('AI returned invalid analysis format. Please try again.');
    return JSON.parse(jsonMatch[0]);
  }

  // ---- Study Plan Generator ----
  async function generateStudyPlan({ subjects, examDate, hoursPerDay, remainingTopics, preferences }) {
    const daysUntilExam = Math.max(1, Math.ceil((new Date(examDate) - new Date()) / (1000 * 60 * 60 * 24)));

    const systemPrompt = `You are StudyMate AI, creating a personalized study plan for an Indian college student.

Return ONLY a valid JSON object:
{
  "title": "Study Plan for [exam/subject]",
  "summary": "Brief plan description",
  "tasks": [
    {
      "id": "t1",
      "date": "YYYY-MM-DD",
      "title": "Study: [Topic name]",
      "subject": "Subject name",
      "type": "study",
      "duration": 90,
      "completed": false,
      "priority": "high",
      "description": "What to cover"
    }
  ]
}
Task types: "study" | "revision" | "quiz" | "pyq_practice" | "break" | "rest"
Distribute tasks across ${daysUntilExam} days. Max ${hoursPerDay} hours/day.
Prioritize weaker topics. Include revision and practice sessions.
Keep tasks realistic and achievable.`;

    const messages = [{
      role: 'user',
      content: `Create a study plan.\nDays until exam: ${daysUntilExam}\nHours/day: ${hoursPerDay}\nSubjects: ${subjects.join(', ')}\nTopics to cover: ${remainingTopics || 'All topics'}\nPreferences: ${preferences || 'Standard'}`
    }];

    const raw = await callAI({ messages, systemPrompt, maxTokens: 3000, temperature: 0.5 });
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('AI returned invalid plan format.');
    return JSON.parse(jsonMatch[0]);
  }

  return {
    isConfigured,
    getApiKey,
    callAI,
    ragChat,
    generateNotes,
    generateQuiz,
    generateFlashcards,
    analyzePYQs,
    generateStudyPlan,
    MODE_PROMPTS,
  };
})();

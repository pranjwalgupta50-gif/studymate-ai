/**
 * StudyMate AI — Landing Page
 */
window.LandingPage = {
  render() {
    const root = document.getElementById('app-root');
    if (!root) return;

    root.innerHTML = `
      <!-- Public Nav -->
      <nav class="landing-nav">
        <a class="landing-nav-logo" href="#/">
          <div class="landing-nav-logo-icon">📚</div>
          <span>StudyMate <strong>AI</strong></span>
        </a>
        <div class="landing-nav-links">
          <button class="landing-nav-link" onclick="LandingPage.scrollTo('how')">How It Works</button>
          <button class="landing-nav-link" onclick="LandingPage.scrollTo('features')">Features</button>
          <button class="landing-nav-link" onclick="LandingPage.scrollTo('pricing-section')">Pricing</button>
          <button class="landing-nav-link" onclick="LandingPage.scrollTo('faq-section')">FAQ</button>
        </div>
        <div class="landing-nav-actions">
          <a href="#/login" class="btn btn-ghost btn-sm">Log In</a>
          <a href="#/register" class="btn btn-primary btn-sm">Get Started Free</a>
        </div>
      </nav>

      <div class="landing-content">
        <!-- Hero -->
        <section class="hero" id="hero">
          <div class="hero-content">
            <div class="hero-badge">
              <div class="hero-badge-dot"></div>
              ✨ AI-Powered Study Assistant for Indian Students
            </div>
            <h1 class="hero-title">
              Your <span class="text-gradient">AI Study Partner</span><br/>for College
            </h1>
            <p class="hero-subtitle">
              Upload your syllabus, notes and previous-year papers. StudyMate AI turns them into personalized notes, quizzes, revision material and study plans.
            </p>
            <div class="hero-cta">
              <a href="#/register" class="btn btn-primary btn-xl">
                🚀 Start Studying Free
              </a>
              <button class="btn btn-outline btn-xl" onclick="LandingPage.scrollTo('how')">
                ▶ Explore Features
              </button>
            </div>
            <div class="hero-social-proof">
              <div class="hero-proof-item"><span class="hero-proof-icon">✓</span> No credit card required</div>
              <div class="hero-proof-item"><span class="hero-proof-icon">✓</span> Works with your own documents</div>
              <div class="hero-proof-item"><span class="hero-proof-icon">✓</span> Built for Indian universities</div>
            </div>
          </div>
        </section>

        <!-- How It Works -->
        <section id="how" style="background:var(--bg-raised);padding:var(--space-24) var(--space-8);">
          <div style="max-width:var(--content-max-width);margin:0 auto;">
            <div class="section-header">
              <div class="section-label">How It Works</div>
              <h2 class="section-title">Study smarter in 4 simple steps</h2>
              <p class="section-desc" style="margin:0 auto;">
                StudyMate AI uses your own academic material — not generic internet content — to help you prepare for exams.
              </p>
            </div>
            <div class="grid grid-4 stagger" style="margin-top:64px;">
              ${[
                { num:1, icon:'⬆️', title:'Upload Your Material', desc:'Upload your syllabus, class notes, PDF books, PYQs, or any academic document.' },
                { num:2, icon:'🔬', title:'AI Processes It', desc:'StudyMate AI extracts text, creates smart chunks, and builds a searchable knowledge base from your documents.' },
                { num:3, icon:'💬', title:'Ask & Learn', desc:'Chat with AI about your material. Ask questions, get explanations, generate notes, quizzes, and flashcards.' },
                { num:4, icon:'📊', title:'Track Progress', desc:'Monitor your quiz scores, weak topics, completed study sessions, and exam readiness.' },
              ].map(s => `
                <div class="how-step-card">
                  <div class="how-step-number">${s.num}</div>
                  <div class="how-step-icon">${s.icon}</div>
                  <h3 class="how-step-title">${s.title}</h3>
                  <p class="how-step-desc">${s.desc}</p>
                </div>
              `).join('')}
            </div>
          </div>
        </section>

        <!-- Features -->
        <section id="features" class="section">
          <div class="section-header">
            <div class="section-label">Features</div>
            <h2 class="section-title">Everything you need to ace your exams</h2>
            <p class="section-desc" style="margin:0 auto;">
              Built specifically for B.Tech, BCA, BBA, MCA and other Indian college students.
            </p>
          </div>
          <div class="grid grid-3 stagger" style="margin-top:64px;gap:24px;">
            ${[
              { icon:'💬', title:'AI Study Chat (RAG)', desc:'Ask questions from your uploaded material. The AI retrieves relevant sections and answers based on your actual notes — not generic internet content.', badge:'Core Feature' },
              { icon:'📝', title:'Smart Notes Generator', desc:'Generate quick notes, detailed notes, exam notes, or revision summaries from any uploaded document or topic.', badge:'AI-Powered' },
              { icon:'✏️', title:'AI Quiz Generator', desc:'Create MCQs, True/False, short answer, and fill-in-the-blank questions from your study material with explanations.', badge:'Exam Prep' },
              { icon:'🔍', title:'PYQ Analyzer', desc:'Upload previous year question papers. The AI identifies repeated topics, patterns, and important questions across multiple years.', badge:'Smart Analysis' },
              { icon:'📅', title:'Study Planner', desc:'Generate personalized daily and weekly study schedules based on your exam date, subjects, and available study hours.', badge:'AI Planner' },
              { icon:'🃏', title:'Flashcard Generator', desc:'Automatically generate flashcards from your study material. Review with flip animation, mark difficult cards, and track learning.', badge:'Active Recall' },
              { icon:'⏱️', title:'Exam Mode', desc:'Practice timed tests with questions from your uploaded material. Get topic-wise performance analysis after each attempt.', badge:'Practice Tests' },
              { icon:'📊', title:'Progress Tracking', desc:'Track study time, quiz scores, topics covered, weak areas, and revision progress — all based on your actual activity.', badge:'Analytics' },
              { icon:'🧠', title:'Adaptive Learning', desc:'The system identifies your weak topics from quiz performance and adjusts your study plan to focus on areas that need improvement.', badge:'Personalized' },
            ].map(f => `
              <div class="feature-card">
                <div class="feature-icon">${f.icon}</div>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                  <h3 style="font-size:16px;font-weight:700;">${f.title}</h3>
                  <span class="badge badge-primary" style="font-size:9px;">${f.badge}</span>
                </div>
                <p style="font-size:13px;color:var(--text-secondary);line-height:1.6;">${f.desc}</p>
              </div>
            `).join('')}
          </div>
        </section>

        <!-- For Indian Students -->
        <section style="background:linear-gradient(135deg,#4F46E5 0%,#7C3AED 50%,#06B6D4 100%);padding:80px 32px;text-align:center;">
          <div style="max-width:800px;margin:0 auto;color:white;">
            <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;opacity:0.8;margin-bottom:12px;">Designed for India</div>
            <h2 style="font-size:clamp(28px,5vw,48px);font-weight:900;color:white;margin-bottom:20px;letter-spacing:-0.03em;">
              Built for Indian College Students
            </h2>
            <p style="font-size:16px;opacity:0.9;max-width:580px;margin:0 auto 40px;line-height:1.7;">
              StudyMate AI understands Indian academic structure — semesters, units, modules, internal exams, end-semester exams, and PYQ patterns from Indian universities.
            </p>
            <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:12px;margin-bottom:40px;">
              ${['B.Tech','BCA','BBA','MCA','MBA','B.Sc','M.Sc','B.Com','BA','MA'].map(c =>
                `<span style="background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.3);padding:6px 16px;border-radius:9999px;font-size:13px;font-weight:600;color:white;">${c}</span>`
              ).join('')}
            </div>
            <a href="#/register" class="btn btn-xl" style="background:white;color:#4F46E5;border:none;font-weight:700;">
              🎓 Start Studying Free
            </a>
          </div>
        </section>

        <!-- AI Chat Showcase -->
        <section class="section" id="chat-demo">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;">
            <div>
              <div class="section-label">AI Study Chat</div>
              <h2 class="section-title section-title-sm">Ask questions from your own material</h2>
              <p class="section-desc" style="margin-bottom:24px;">
                Unlike generic AI chatbots, StudyMate AI only answers from your uploaded documents. It tells you exactly which source it used and when information isn't available in your material.
              </p>
              <div style="display:flex;flex-direction:column;gap:12px;">
                ${[
                  '📌 Source-grounded answers from your documents',
                  '📖 Cites the document and page number',
                  '🎯 Study modes: Simple, Detailed, Exam-Ready',
                  '🔄 Follow-up questions and regenerate answers',
                  '💾 Save and organize your chats by subject',
                ].map(f => `<div style="display:flex;align-items:center;gap:10px;font-size:14px;color:var(--text-secondary);">${f}</div>`).join('')}
              </div>
            </div>
            <div class="chat-showcase" style="background:#0F172A;border-radius:20px;padding:24px;">
              <div style="display:flex;flex-direction:column;gap:16px;">
                <div style="display:flex;gap:10px;align-items:flex-start;">
                  <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#4F46E5,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:14px;color:white;flex-shrink:0;">S</div>
                  <div style="background:rgba(79,70,229,0.3);border:1px solid rgba(79,70,229,0.4);padding:12px 16px;border-radius:12px;border-bottom-left-radius:4px;color:rgba(255,255,255,0.9);font-size:13px;line-height:1.6;">
                    What is normalization in DBMS? Explain with examples.
                  </div>
                </div>
                <div style="display:flex;gap:10px;align-items:flex-start;">
                  <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#7C3AED,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:14px;color:white;flex-shrink:0;">🤖</div>
                  <div>
                    <div style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);padding:14px 16px;border-radius:12px;border-bottom-left-radius:4px;color:rgba(255,255,255,0.85);font-size:13px;line-height:1.7;">
                      <strong style="color:white;">Normalization in DBMS</strong><br/><br/>
                      Based on your uploaded DBMS notes (Unit 3, Page 45):<br/><br/>
                      Normalization is the process of organizing database tables to <strong>reduce data redundancy</strong> and improve data integrity...<br/><br/>
                      <strong>1NF:</strong> Eliminate repeating groups<br/>
                      <strong>2NF:</strong> Remove partial dependencies<br/>
                      <strong>3NF:</strong> Remove transitive dependencies
                    </div>
                    <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
                      <span style="background:rgba(79,70,229,0.2);border:1px solid rgba(79,70,229,0.3);padding:3px 10px;border-radius:9999px;font-size:11px;color:#818CF8;">📄 DBMS Notes.pdf · Page 45</span>
                    </div>
                    <div style="font-size:11px;color:rgba(255,255,255,0.4);margin-top:6px;">⚠️ AI-generated — verify important information</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Pricing Section -->
        <section id="pricing-section" style="background:var(--bg-raised);padding:80px 32px;">
          <div style="max-width:900px;margin:0 auto;">
            <div class="section-header">
              <div class="section-label">Pricing</div>
              <h2 class="section-title">Simple, transparent pricing</h2>
              <p class="section-desc" style="margin:0 auto;">Start free. Upgrade when you need more.</p>
            </div>
            <div class="grid grid-2" style="margin-top:48px;gap:24px;">
              <div class="pricing-card">
                <div class="pricing-name">Free</div>
                <div class="pricing-price">₹0</div>
                <div class="pricing-period">forever</div>
                <div class="pricing-desc">Perfect for getting started with AI-powered studying.</div>
                <div class="pricing-features">
                  ${[
                    [true,'5 PDF uploads/month'],
                    [true,'50 AI questions/month'],
                    [true,'5 Quiz generations/month'],
                    [true,'5 Notes generations/month'],
                    [true,'2 PYQ analyses/month'],
                    [true,'Basic study planner'],
                    [false,'Export notes'],
                    [false,'Advanced analytics'],
                    [false,'Priority AI responses'],
                  ].map(([has, label]) => `
                    <div class="pricing-feature">
                      <span class="pricing-feature-icon ${has ? '' : 'no'}">${has ? '✓' : '✕'}</span>
                      <span style="${has ? '' : 'color:var(--text-muted)'}">${label}</span>
                    </div>
                  `).join('')}
                </div>
                <a href="#/register" class="btn btn-outline w-full" style="width:100%;justify-content:center;">Get Started Free</a>
              </div>
              <div class="pricing-card featured">
                <div class="pricing-badge">Most Popular</div>
                <div class="pricing-name">Premium</div>
                <div class="pricing-price">₹299</div>
                <div class="pricing-period">per month · ₹2,499/year (save 30%)</div>
                <div class="pricing-desc">For students who want the full power of AI study tools.</div>
                <div class="pricing-features">
                  ${[
                    [true,'50 PDF uploads/month'],
                    [true,'500 AI questions/month'],
                    [true,'50 Quiz generations/month'],
                    [true,'50 Notes generations/month'],
                    [true,'20 PYQ analyses/month'],
                    [true,'Advanced study planner'],
                    [true,'Export notes (PDF/Print)'],
                    [true,'Advanced analytics'],
                    [true,'Priority AI responses'],
                  ].map(([has, label]) => `
                    <div class="pricing-feature">
                      <span class="pricing-feature-icon ${has ? '' : 'no'}">${has ? '✓' : '✕'}</span>
                      <span>${label}</span>
                    </div>
                  `).join('')}
                </div>
                <a href="#/register" class="btn btn-primary w-full" style="width:100%;justify-content:center;">
                  💎 Get Premium
                </a>
                <p style="font-size:11px;color:var(--text-muted);text-align:center;margin-top:8px;">
                  Payment integration coming soon. Sign up now and get notified.
                </p>
              </div>
            </div>
          </div>
        </section>

        <!-- FAQ -->
        <section id="faq-section" class="section">
          <div style="max-width:720px;margin:0 auto;">
            <div class="section-header">
              <div class="section-label">FAQ</div>
              <h2 class="section-title">Frequently asked questions</h2>
            </div>
            <div style="display:flex;flex-direction:column;gap:12px;" id="faq-list">
              ${[
                { q:'How does StudyMate AI answer my questions?', a:'StudyMate AI uses a technique called RAG (Retrieval-Augmented Generation). When you ask a question, it first searches your uploaded documents for the most relevant sections, then sends that context to the AI to generate an answer based on your material.' },
                { q:'Can I use it without uploading documents?', a:'Yes, but the AI will rely on general knowledge rather than your specific material. For exam-focused answers from your syllabus and notes, we strongly recommend uploading your academic documents.' },
                { q:'What file types does StudyMate AI support?', a:'Currently PDF, TXT, and DOCX files are supported. PDF is recommended. Note that image-only PDFs (scanned without OCR) may not have extractable text.' },
                { q:'Is my uploaded data private and secure?', a:'Your documents and study data are associated with your account only. Other users cannot access your material. We do not share your data with third parties.' },
                { q:'How accurate are the AI-generated answers?', a:'AI answers are generated based on your uploaded material and are generally accurate. However, AI can make errors. Always verify important information with your textbook or instructor before exams.' },
                { q:'What is PYQ Analysis?', a:'PYQ Analysis allows you to upload multiple previous year question papers. StudyMate AI then identifies which topics appear repeatedly, how many times each topic has appeared across years, and classifies topics by frequency — helping you prioritize your study.' },
                { q:'Does StudyMate AI predict exam questions?', a:'No. StudyMate AI does not predict or guarantee that any topic will appear in your exam. It only analyzes what has appeared in past papers and helps you identify patterns. Always study comprehensively.' },
              ].map((faq, i) => `
                <div class="faq-item" id="faq-${i}">
                  <div class="faq-question" onclick="LandingPage.toggleFaq(${i})">
                    <span>${faq.q}</span>
                    <span class="faq-chevron">▾</span>
                  </div>
                  <div class="faq-answer">${faq.a}</div>
                </div>
              `).join('')}
            </div>
          </div>
        </section>

        <!-- Footer CTA -->
        <section style="text-align:center;padding:80px 32px;background:var(--bg-raised);">
          <h2 style="font-size:36px;font-weight:900;letter-spacing:-0.03em;margin-bottom:16px;">
            Ready to study smarter?
          </h2>
          <p style="font-size:16px;color:var(--text-secondary);margin-bottom:36px;max-width:500px;margin-left:auto;margin-right:auto;">
            Join thousands of Indian college students using AI to prepare for their exams more effectively.
          </p>
          <a href="#/register" class="btn btn-primary btn-xl">🚀 Start for Free — No Credit Card</a>
        </section>

        <!-- Footer -->
        <footer style="background:var(--gray-900);color:var(--gray-400);padding:48px 32px;text-align:center;">
          <div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:16px;">
            <div style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#4F46E5,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:14px;">📚</div>
            <span style="color:white;font-weight:700;font-size:16px;">StudyMate AI</span>
          </div>
          <p style="font-size:13px;margin-bottom:8px;">AI-powered study assistant for Indian college students</p>
          <p style="font-size:12px;opacity:0.6;">© 2024 StudyMate AI. Built for students. All AI-generated content should be verified before exams.</p>
          <div style="display:flex;justify-content:center;gap:24px;margin-top:20px;flex-wrap:wrap;">
            <a href="#/help" style="color:var(--gray-400);font-size:13px;">Help & FAQ</a>
            <a href="#/pricing" style="color:var(--gray-400);font-size:13px;">Pricing</a>
            <a href="#/login" style="color:var(--gray-400);font-size:13px;">Log In</a>
            <a href="#/register" style="color:var(--gray-400);font-size:13px;">Get Started</a>
          </div>
        </footer>
      </div>
    `;
  },

  toggleFaq(index) {
    const faq = document.getElementById(`faq-${index}`);
    if (faq) faq.classList.toggle('open');
  },

  scrollTo(id) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  },
};

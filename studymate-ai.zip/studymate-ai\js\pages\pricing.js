/**
 * StudyMate AI — Pricing Page
 */
window.PricingPage = {
  render() {
    const root = document.getElementById('app-root');
    const plan = DB.Subscriptions.getCurrentPlan();

    root.innerHTML = AppShell.renderLayout('Pricing & Plans', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">💎 Subscription Plans</h1>
          <p class="page-subtitle">Simple, transparent pricing. No hidden fees.</p>
        </div>
      </div>

      <div style="max-width:800px;margin:0 auto;">
        <div class="pricing-toggle" style="text-align:center;margin-bottom:40px;">
          <span style="font-size:14px;color:var(--text-muted);">Your current plan: </span>
          <span class="badge ${plan === 'premium' ? 'badge-warning' : 'badge-gray'}" style="font-size:14px;padding:6px 16px;">
            ${plan === 'premium' ? '💎 Premium' : '🆓 Free'}
          </span>
        </div>

        <div class="grid grid-2" style="gap:24px;margin-bottom:48px;">
          <!-- Free -->
          <div class="pricing-card ${plan === 'free' ? 'current' : ''}">
            ${plan === 'free' ? '<div class="pricing-badge" style="background:var(--gray-500);">Current Plan</div>' : ''}
            <div class="pricing-name">Free</div>
            <div class="pricing-price">₹0</div>
            <div class="pricing-period">forever</div>
            <div class="pricing-desc">Perfect for getting started with AI-powered studying.</div>
            <div class="pricing-features">
              ${[
                [true,'5 PDF uploads/month'],
                [true,'50 AI questions/month'],
                [true,'5 Quiz generations/month'],
                [true,'5 Notes generations/month'],
                [true,'2 PYQ analyses/month'],
                [true,'Study planner'],
                [true,'Flashcards'],
                [false,'Export notes'],
                [false,'Advanced analytics'],
                [false,'Priority AI responses'],
              ].map(([has, label]) => `
                <div class="pricing-feature">
                  <span class="pricing-feature-icon ${has ? '' : 'no'}">${has ? '✓' : '✕'}</span>
                  <span style="${has ? '' : 'opacity:0.5'}">${label}</span>
                </div>
              `).join('')}
            </div>
            <button class="btn ${plan === 'free' ? 'btn-ghost' : 'btn-outline'}" style="width:100%;justify-content:center;" disabled>
              ${plan === 'free' ? '✓ Current Plan' : 'Free Plan'}
            </button>
          </div>

          <!-- Premium -->
          <div class="pricing-card featured">
            <div class="pricing-badge">Most Popular</div>
            <div class="pricing-name">Premium</div>
            <div class="pricing-price">₹299</div>
            <div class="pricing-period">per month</div>
            <div style="font-size:12px;color:var(--brand-success);margin-bottom:8px;text-align:center;">or ₹2,499/year (save 30%)</div>
            <div class="pricing-desc">For students who want the full power of AI study tools.</div>
            <div class="pricing-features">
              ${[
                [true,'50 PDF uploads/month'],
                [true,'500 AI questions/month'],
                [true,'50 Quiz generations/month'],
                [true,'50 Notes generations/month'],
                [true,'20 PYQ analyses/month'],
                [true,'Advanced study planner'],
                [true,'Flashcards'],
                [true,'Export notes (PDF/Print)'],
                [true,'Advanced analytics'],
                [true,'Priority AI responses'],
              ].map(([has, label]) => `
                <div class="pricing-feature">
                  <span class="pricing-feature-icon">${has ? '✓' : '✕'}</span>
                  <span>${label}</span>
                </div>
              `).join('')}
            </div>
            ${plan === 'premium'
              ? `<button class="btn btn-success" style="width:100%;justify-content:center;" disabled>✓ You're on Premium</button>`
              : `<button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="PricingPage.upgrade()">
                  💎 Upgrade to Premium
                </button>`
            }
          </div>
        </div>

        <!-- Payment note -->
        <div class="alert alert-neutral" style="text-align:center;">
          <span class="alert-icon">ℹ</span>
          <div>
            <strong>Payment integration coming soon.</strong> Sign up now, get notified when payment goes live, and we'll credit your first month free.
            <br/>
            <button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="PricingPage.notifyMe()">🔔 Notify Me When Available</button>
          </div>
        </div>

        <!-- FAQ -->
        <div style="margin-top:48px;">
          <h2 style="font-size:22px;font-weight:800;text-align:center;margin-bottom:24px;">Frequently Asked Questions</h2>
          <div style="display:flex;flex-direction:column;gap:10px;">
            ${[
              {q:'Can I switch plans anytime?', a:'Yes. You can upgrade or downgrade your plan at any time. Changes take effect immediately.'},
              {q:'What happens to my data if I downgrade?', a:'Your documents, notes, and history remain accessible. Only new uploads/generations will be limited to the free plan limits.'},
              {q:'Is there a student discount?', a:'We are working on special pricing for verified students from Indian colleges. Stay tuned.'},
              {q:'Do you offer refunds?', a:'Yes. We offer a 7-day refund if you\'re not satisfied with Premium. Contact us within 7 days of purchase.'},
            ].map((f, i) => `
              <div class="faq-item" id="price-faq-${i}">
                <div class="faq-question" onclick="this.parentElement.classList.toggle('open')">
                  <span>${f.q}</span><span class="faq-chevron">▾</span>
                </div>
                <div class="faq-answer">${f.a}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `);
  },

  upgrade() {
    Modal.show(`
      <div class="modal-header">
        <h3 class="modal-title">💎 Upgrade to Premium</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <div style="text-align:center;padding:16px 0;">
          <div style="font-size:48px;margin-bottom:16px;">🚧</div>
          <h3 style="font-size:18px;font-weight:700;margin-bottom:8px;">Payment Coming Soon</h3>
          <p style="font-size:14px;color:var(--text-muted);max-width:300px;margin:0 auto 20px;">
            Razorpay/UPI payment integration is being set up. Sign up for early access and get your first month free!
          </p>
          <div class="form-group">
            <label class="form-label">Your Email</label>
            <input class="form-input" type="email" id="notify-email" value="${AuthService.getCurrentUser()?.email || ''}" />
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
        <button class="btn btn-primary" onclick="PricingPage.saveNotification()">🔔 Notify Me</button>
      </div>
    `);
  },

  notifyMe() {
    this.upgrade();
  },

  saveNotification() {
    Toast.success('You\'ll be notified when Premium goes live!');
    Modal.close();

    // Demo: Immediately activate premium for testing
    Modal.confirm('For demo purposes, would you like to activate Premium now?', () => {
      DB.Subscriptions.upgrade('premium');
      Toast.success('💎 Premium activated! Enjoy unlimited AI study tools.');
      this.render();
    }, { title: 'Activate Demo Premium', confirmText: 'Yes, Activate Premium' });
  },
};

/**
 * Help & FAQ Page
 */
window.HelpPage = {
  render() {
    const root = document.getElementById('app-root');
    root.innerHTML = AppShell.renderLayout('Help & FAQ', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">❓ Help & FAQ</h1>
          <p class="page-subtitle">Find answers to common questions about StudyMate AI</p>
        </div>
      </div>

      <div style="max-width:760px;margin:0 auto;display:flex;flex-direction:column;gap:16px;">
        ${[
          { section: 'Getting Started' },
          { q:'How do I start using StudyMate AI?', a:'Upload your study material (syllabus, notes, PYQs, textbooks) in PDF or TXT format from the Documents page. Once processed, you can chat with AI, generate notes, create quizzes, and more — all based on your uploaded content.' },
          { q:'What file formats are supported?', a:'PDF, TXT, and DOCX files are supported. PDF is recommended for best results. Note: Image-only/scanned PDFs without embedded text may not work — your PDF must have selectable text.' },
          { q:'Why isn\'t the AI working?', a:'You need to configure your Gemini API key in Profile → AI Settings. Get a free Gemini API key from Google AI Studio (aistudio.google.com). The AI connects directly via your API key.' },
          { section: 'AI Chat' },
          { q:'Why does the AI say it can\'t find information?', a:'The AI only searches your uploaded documents. If you haven\'t uploaded a specific document, it won\'t have that information. Upload your relevant notes or textbook and try again.' },
          { q:'What are Study Modes?', a:'Simple: Easy explanations. Detailed: Comprehensive coverage. Exam: Exam-ready structured answer. Revision: Quick key points. Technical: Precise, in-depth.' },
          { q:'Are AI-generated answers accurate?', a:'AI answers are based on your uploaded material and are generally accurate, but AI can make errors. Always verify important information with your official textbooks before exams.' },
          { section: 'PYQ Analyzer' },
          { q:'How does PYQ analysis work?', a:'Upload your previous year question papers as PDFs or TXT files, select them in the PYQ Analyzer, and click Analyze. The AI identifies repeated topics, patterns, and question frequencies across papers.' },
          { q:'Can the AI predict exam questions?', a:'No. StudyMate AI does not predict or guarantee any topic will appear in your exam. It only analyzes what has appeared in your uploaded past papers. Study all topics.' },
          { section: 'Privacy & Data' },
          { q:'Is my uploaded data secure?', a:'Your data is stored locally in your browser\'s storage. Each account only sees its own documents and data. In the production version, data would be encrypted and stored securely in the cloud.' },
          { q:'Can other students see my documents?', a:'No. Your uploaded documents and study data are private to your account. Other users cannot access your material.' },
        ].map((item, i) => {
          if (item.section) {
            return `<h2 style="font-size:16px;font-weight:800;color:var(--brand-primary);padding-top:8px;">${item.section}</h2>`;
          }
          return `
            <div class="faq-item" id="help-faq-${i}">
              <div class="faq-question" onclick="this.parentElement.classList.toggle('open')">
                <span>${item.q}</span><span class="faq-chevron">▾</span>
              </div>
              <div class="faq-answer">${item.a}</div>
            </div>
          `;
        }).join('')}

        <div class="card" style="margin-top:24px;text-align:center;">
          <div style="font-size:32px;margin-bottom:12px;">📧</div>
          <h3 style="font-size:16px;font-weight:700;margin-bottom:8px;">Still have questions?</h3>
          <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">Contact us and we'll get back to you within 24 hours.</p>
          <a href="mailto:help@studymateai.in" class="btn btn-outline">📧 help@studymateai.in</a>
        </div>
      </div>
    `);
  },
};
